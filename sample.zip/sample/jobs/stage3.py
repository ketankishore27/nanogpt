# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from poll_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""


import sys
from dependencies.spark import start_spark # pylint: disable=E0401
from dependencies.stage3_utils import *
from dependencies.utils import *

def stage_3(spark, config, log):
    '''
    This is a pipeline for Stage 3

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        log (object) : Spark logging
    
    '''
    stage_header(config, 3, info= " This stage aggregate data per assetid and incident day. Features on windows, by daily basis and treand are calculated.")

    df = spark.read.parquet(config["paths_post_stage2"]['all_model']+"_{}Before_{}After".format(
            str(config['data_preprocessing']['window_before']), str(config['data_preprocessing']['window_after'])
        ))
    df_before, df_after = df.filter("Flag = 'Before'").drop('Flag'), df.filter("Flag = 'After'").drop('Flag')

    # Get Aggregated windowed features
    df_window_agg_before = get_window_features(df, config, mode='before')
    df_window_agg_after = get_window_features(df, config, mode='after')
    print("df_window_agg_before count:{}, df_window_agg_after count: {}".format(df_window_agg_before.count(), df_window_agg_after.count()))

    # Join the above tables to get trends
    df_window_agg = df_window_agg_before.join(df_window_agg_after, \
                                              on = ['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id'],\
                                              how = 'inner')
    df_window_agg = add_trend_features(df_window_agg, config)
    print("DF winfow final count: {}".format(df_window_agg.count()))

    # Get Categorical featues
    df_categorical_before = rename_cols(get_categorical_features(df_before, config), prefix = "before_")
    df_categorical_after = rename_cols(get_categorical_features(df_after, config), prefix = "after_")
    df_categorical = df_categorical_before.join(df_categorical_after, on = ['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id'], how = 'inner')
    df_categorical = df_categorical.fillna("BlankValue")
    print("DF categorical final count: {}".format(df_categorical.count()))
    
    # Combining all the data together
    df_combined = df_window_agg.join(df_categorical, on = ['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id'], how = 'inner')

    if df_combined.rdd.isEmpty():
        log.warn("Processed Dataframe is empty")
    else:
        print('Stage 3 output Schema -:', df_combined.printSchema())
        df_combined.write.format("parquet").mode('overwrite').save(config["paths_post_stage3"]['all_model']+"_{}Before_{}After".format(
            str(config['data_preprocessing']['window_before']), str(config['data_preprocessing']['window_after'])
        ))
        log.warn("Data written to parquet Stage-3")


def main(args):
    '''
    This is a main function for Stage 3
    
    Args:
        args (list) : List of arguments

    '''
    
    print('Length of args : ', len(args))
    print('args : ', args)

    # start Spark application and get Spark session, logger and config
    spark, log, config = start_spark(app_name='repeated_faults_stage3')

    # Cleaning the memory
    log.warn('cleaning memory...')
    spark.catalog.clearCache()

    # Enter Code here 
    stage_3(spark, config, log)

    # log the success and terminate Spark application
    log.warn('Stage 3 - windowing is finished...')
    
    spark.stop()

if __name__ == "__main__":
    main(sys.argv)
