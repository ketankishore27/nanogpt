# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from poll_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""

import sys
from dependencies.spark import start_spark # pylint: disable=E0401
from dependencies.batch_id_update_utils import *
from dependencies.stage6_utils import *
from dependencies.utils import *

def stage6(spark, log, config, cpe_type, args):
    '''
    This is a pipeline for Stage 6

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        cpe_type (str) : CPE Type
        args (list) : List of arguments
    
    '''
    stage_header(config, 
                 stage_number=6, 
                 info='This Stage is for Saving Overall predictions and sening the control group to Kafka and persisting everything into Hive.')
    # PART 1 
    section_header('Get and Save overall Predictions')

    df_stage5 = spark.read.parquet(config["paths_post_stage5"][cpe_type])
    # Format the data for Inference
    df = kpi_inference_format(df_stage5,cpe_type,args)

    # Persist predictions in hive
    df.write.mode('append').format('hive').insertInto(config['paths_post_stage6']['overall_predictions'])

    # PART 2
    section_header('Select top k candidates and send it to kafka and persist into hive tables')


    # Split predictions in 2 groups as per the inventory
    df_A_grp, df_B_grp = create_control_group(df,config, cpe_type,spark)

    # Pick top k candidates from each group
    df_top_A = select_top_k(df_A_grp,cpe_type,config,spark)
    df_top_B = select_top_k(df_B_grp, cpe_type, config, spark)
    df_top = df_top_A.union(df_top_B)
    df_top =  df_top.dropDuplicates()
    df_top.write.format("parquet").mode('overwrite').save(config["paths_post_stage5"][cpe_type]+"_df_top")
    #df_top = spark.read.parquet(config["paths_post_stage5"][cpe_type]+"_df_top")
    
    # Split into control groups
    #df_A, df_B = create_control_group(df_top)


    # Format the Recommended data 
    df_A = recommendation_format(df_top_A)
    df_B = recommendation_format(df_top_B)


    if df_A.rdd.isEmpty():
        log.warn("Processed Dataframe is empty")
    else:
        # Persist into hive
        df_A.write.mode('append').format('hive').insertInto(config['paths_post_stage6']['recommendations'])
        df_B.write.mode('append').format('hive').insertInto(config['paths_post_stage6']['recommendations'])
        log.warn("Data written to Hive Tables")

    # Send it to Kafka
    # df_kafka = kafka_format(df_A)
    # write_batch_on_kafka(df_kafka, config)


def main(args):
    '''
    This is a main function for Stage 6
    
    Args:
        args (list) : List of arguments

    '''
    
    print('Length of args : ', len(args))
    print('args : ', args)

    cpe_type = args[2]

    # start Spark application and get Spark session, logger and config
    spark, log, config = start_spark(app_name='repeateds_stage6')

    # Cleaning the memory
    log.warn('cleaning memory...')
    spark.catalog.clearCache()

    # Enter Code here 
    stage6(spark, log, config, cpe_type,args)

    # log the success and terminate Spark application
    log.warn('Stage 6 - Recommendation is finished ...')

if __name__ == "__main__":
    main(sys.argv)
