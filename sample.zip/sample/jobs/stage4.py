# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from poll_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""

import sys
import os
from dependencies.spark import start_spark
from dependencies.stage4_utils import clipper_transform
from pyspark.ml import PipelineModel
from dependencies.utils import stage_header
from dependencies.stage4_utils import *

os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

def stage4(spark, config, log=None):
    '''
    This is a pipeline for Stage 4

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        log (object) : Spark logging
        cpe_type (str) : CPE Type
    
    '''
    stage_header(config, info= " This stage processes the extracted data and creates the features.")

    # Load Stage 3 data
    df =  spark.read.parquet(config["paths_post_stage3"]['all_model']).drop('features')

    # Fill Null values
    df = handle_nulls(df, config)
    
    # Loading Indexer Pipeline and transform data
    pipeline_categorical = PipelineModel.load(config["paths_post_stage4"]['pipeline'])
    df = pipeline_categorical.transform(df)
    
    features_categorical = ['before_dslam_platforma', 'before_dslam_internet', 'before_dslam_iptv', 'before_dslam_voip', 
                        'before_dslam_card_type','before_dslam_status_porta','before_dslam_vdsl_adsl', 
                        'after_dslam_platforma', 'after_dslam_internet', 'after_dslam_iptv', 'after_dslam_voip', 
                        'after_dslam_card_type','after_dslam_status_porta','after_dslam_vdsl_adsl',
                        'before_normalised_summary']

    features_categorical_index = [feature+'_indexed' for feature in features_categorical]
    df = clipper_transform(df, features_categorical_index, clip=100)
    
    #Drop Duplicates
    cols = df.columns
    df = df.select(*cols).distinct()

    
    print('Data Processing Stage is finished and writing to HDFS..')

    if df.rdd.isEmpty():
        log.warn("Processed Dataframe is empty")
    else:
        df.write.format("parquet").mode('overwrite').save(config["paths_post_stage4"]['all_model'])
        print("Data written to parquet at location: {}".format(config["paths_post_stage4"]['all_model']))


def main_stage4():
    '''
    This is a main function for Stage 4
    
    Args:
        args (list) : List of arguments

    '''
    
    # start Spark application and get Spark session, logger and config
    spark, config = start_spark(app_name='repeateds_stage4')

    # Cleaning the memory
    print('cleaning memory...')
    spark.catalog.clearCache()

    # Enter Code here 
    stage4(spark, config)

    # log the success and terminate Spark application
    print('Extracting and Processing is finished ...')

    
