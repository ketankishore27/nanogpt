# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from pol_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""


from dependencies.spark import start_spark # pylint: disable=E0401
from dependencies.stage2_utils import *
from dependencies.batch_id_update_utils import get_time
from dependencies.utils import *
import sys


def stage_2(spark, config, log):
    '''
    This is a pipeline for Stage 2

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        log (object) : Spark logging
    
    '''
    stage_header(config, 
                 stage_number=2, 
                 info='This module collects data from pol_day_aggregation and xsdl tables and define inventory per CPE type')
    
    # log the success and terminate Spark application
    df_inventory = spark.read.parquet(config["paths_post_stage1"]['all_model']+"_{}Before_{}After".format(
            str(config['data_preprocessing']['window_before']), str(config['data_preprocessing']['window_after'])
        ))
    
    # Get start and end dates
    start_time, end_time = get_dates(df_inventory, config)

    # Gather data from multiple table only on N days defore the incident date per asset id
    df_dslam, df_snmp, df_acs = precheck_gather_data(spark, df_inventory,  start_time, end_time, config)
    
    # During traning difference between start_time, end_time is huge then persist query is necesary
    df_dslam, df_snmp, df_acs = intermediate_boost(spark, df_dslam, df_snmp, df_acs, config)
    
    # Preprocess and combine multiple data sources given just one row per day
    df_gathered = gather_data(spark,df_inventory, df_dslam, df_snmp, df_acs, config)

    # Drop Duplicates
    cols = df_gathered.columns
    df_gathered = df_gathered.select(*cols).distinct()

    print('Data gathering is finished and writing to HDFS..')

    if df_gathered.rdd.isEmpty():
        log.warn("Processed Dataframe is empty")
        print("Processed Dataframe is empty")
    else:
        print('Stage 2 output Schema -:', df_gathered.printSchema())
        print("DF gathered count: {}".format(df_gathered.select(['assetid','incident_start_date', 'incident_end_date', 'ticket_id']).distinct().count()))
        df_gathered.write.format("parquet").mode('overwrite').save(config["paths_post_stage2"]['all_model']+"_{}Before_{}After".format(
            str(config['data_preprocessing']['window_before']), str(config['data_preprocessing']['window_after'])
        ))
        log.warn("Data written to parquet for "+ " .")

def main(args):
    '''
    This is a main function for Stage 2

    Args:
        args (list) : List of arguments

    '''
    print('Length of args : ', len(args))
    print('args : ', args)

    # Start Spark application and get Spark session, logger and config
    spark, log, config = start_spark(app_name='repeated_faults_stage2')

    # Cleaning the memory
    log.warn('cleaning memory...')
    spark.catalog.clearCache()
    
    # Start stage 2
    log.warn('Starting to Run Stage 2...')
    stage_2(spark, config, log)

    # Log the success and terminate Spark application
    log.warn('Stage 2 - pre_processing is finished')
    spark.stop()

if __name__ == "__main__":
    main(sys.argv)
