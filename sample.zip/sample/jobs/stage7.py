# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from poll_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""

from dependencies.spark import start_spark # pylint: disable=E0401
from dependencies.stage7_utils import *  # pylint: disable=E0401
from dependencies.stage1_utils import * 
from dependencies.utils import *
import datetime as dt
import sys
from dependencies.batch_id_update_utils import *


def stage_7(spark, config, log, cpe_type,args):
    '''
    This is a pipeline for Stage 7

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        log (object) : Spark logging
        cpe_type (str) : CPE Type
        args (list) : List of arguments
    
    '''
    stage_header(config, 
                 stage_number=7, 
                 info='This Stage is for logging for different stages such as count from each databases.')
    
    # log the success and terminate Spark application

    # Load Stage 1 output
    df_inventory = spark.read.parquet(config["paths_post_stage1"][cpe_type])

    # Load Boosting stage output
    df_dslam = load_data(config["paths_post_stage2"][cpe_type]+'_boost_dslam',spark)
    df_snmp = load_data(config["paths_post_stage2"][cpe_type]+'_boost_snmp',spark)
    df_acs = load_data(config["paths_post_stage2"][cpe_type]+'_boost_acs',spark)

    # Load Stage 2 output
    df_stage2 = load_data(config["paths_post_stage2"][cpe_type],spark)

    # Load Stage 3 output
    df_stage3 = load_data(config["paths_post_stage3"][cpe_type], spark)

    # Load Recommendation stage output
    end_time = (dt.datetime.now() - timedelta(days=config['timedeltas']['gap_incident_date']))

    df_stage6 = spark.sql("""
                     select * from {table} where event_date == '{incident_date}'
                    """.format(table = config['paths_post_stage6']['recommendations'], incident_date = end_time))

    # Log Combined Raw counts
    df_raw_counts = raw_counts_df(args,spark,config)

    # Log Technical parameters
    # df_data_drift = data_drift(df_stage2,config,args,cpe_type)
    
    # Log Pipeline flow
    df_funnel = funnel(df_inventory, df_stage3, df_dslam, df_snmp, df_acs, spark, config, args, cpe_type)

    # Log Recommendation
    df_recom_stats = recommendation_stats(df_stage6)

    print('Logging is finished and writing to HDFS..')

    if df_recom_stats.rdd.isEmpty():
        log.warn("Processed Dataframe is empty")
    else:
        df_raw_counts.write.mode('append').format('hive').insertInto(config['paths_post_stage7']['raw_counts'])
        # df_data_drift.write.mode('append').format('hive').insertInto(config['paths_post_stage7']['data_drift'])
        df_funnel.write.mode('append').format('hive').insertInto(config['paths_post_stage7']['funnel'])
        df_recom_stats.write.mode('append').format('hive').insertInto(config['paths_post_stage7']['recommendation_stats'])
        log.warn("Data written to parquet for "+ cpe_type + " .")

def main(args):
    '''
    This is a main function for Stage 7

    Args:
        args (list) : List of arguments

    '''

    print('Length of args : ', len(args))
    print('args : ', args)

    cpe_type = args[2]
    # Start Spark application and get Spark session, logger and config
    spark, log, config = start_spark(app_name='repeateds_stage7')

    # Cleaning the memory
    log.warn('cleaning memory...')
    spark.catalog.clearCache()
    
    # Start stage 2
    log.warn('Starting to Run Stage 7...')
    stage_7(spark, config, log, cpe_type,args)

    # Log the success and terminate Spark application
    log.warn('Stage 7 - Logging is finished')
    spark.stop()

if __name__ == "__main__":
    main(sys.argv)
