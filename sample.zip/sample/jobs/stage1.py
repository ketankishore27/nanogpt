# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects the tickets from the ticketdb and create a list of eligible tickets.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""


import sys
import os
from dependencies.spark import start_spark # pylint: disable=E0401
from dependencies.utils import *
from dependencies.stage1_utils import *
from dependencies.batch_id_update_utils import get_time

os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable

def create_inventory(spark, config, mode = None, solution_lvl=None, log=None):
    """
    This function creates tickets based on the situation if the pipeline is run in training mode or testing mode
    Args:
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary
        training: flag which describes the mode in which DAG is run
    
    Returns:
        data_inventory (dataframe) : Output dataframe consists of tickets that either needs to be predicted or need to be trained on. 
    """
    if mode == 'Training':
        stage_header(config, 
                    info='This module creates the inventory for training mode')
        # Get all the tickets
        data_ticket = extract_raw_tickets(spark, config, solution_lvl, log)
        # Duplicates above dataframe and creates copies of it.
        data_ticket1, data_ticket2 = alias_frames(data_ticket, spark, version=1, log=log), alias_frames(data_ticket, spark, version=2, log=log)
        # Creates follow-up tickets based on the 30 day difference between start and complete date
        followup_tkts = create_followup_tickets(data_ticket1, data_ticket2, spark, config)
        # Creates those tickets which did have a follow up
        no_followup_tkts = create_nofollowup_ticket(data_ticket, spark, config)
        # Combine those dataframe together
        data_inventory = followup_tkts.union(no_followup_tkts)
    elif mode == 'Inference':
        stage_header(config, 
                    info='This module creates the inventory for inference mode')
        # Filter assetid who have raised ticket in the first 2 days
        data_inventory = get_inference_data(spark, config, solution_lvl, log)

    else:
        stage_header(config,
                    info='No Mode selected thus no data selected')

    data_inventory.write.parquet(config["paths_post_stage1"]['all_model'], mode='overwrite')
    print("Data written to the following location: {}".format(config["paths_post_stage1"]['all_model']))


def main_stage1(pipeline_mode, solution_level):
    """Main function"""    '''
    This is a main function for Stage 1

    Args:
        args (list) : List of arguments

    '''



    # start Spark application and get Spark session, logger and config
    spark, config = start_spark(app_name='repeated_faults_stage1')

    # Cleaning the memory
    print('\ncleaning memory...\n')
    spark.catalog.clearCache()
    
    # Start stage 1
    print('\nStarting to Run Stage 1...\n')
    create_inventory(spark, config, pipeline_mode, solution_level, log=None)

    # Log the success and terminate Spark application
    print('\nStage 1 - Inventory is finished\n')
    spark.stop()

