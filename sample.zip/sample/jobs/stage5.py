# -*- coding: utf-8 -*-
"""
create_inventory.py

This module collects data from poll_day_aggregation and xsdl tables and define inventory per CPE type.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""


import sys
from dependencies.spark import start_spark
from pyspark.ml import PipelineModel
from pyspark.ml.classification import GBTClassificationModel
from dependencies.stage5_utils import *

def stage5(spark, config, log=None):
    '''
    This is a pipeline for Stage 5

    Args:
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        log (object) : Spark logging
        cpe_type (str) : CPE Type
    
    '''
    
    # Load Stage 4 data
    df =  spark.read.parquet(config["paths_post_stage4"]['all_model'])

    # Loading models
    model = GBTClassificationModel.load(config["paths_post_stage5"]['model_file'])
    
    # Data Transformation
    df = get_pred(df, model)
        
    # Select columns
    features_select =  ['assetid', 'incident_start_date', 'incident_end_date', 'probability_unhealty_1']
    if 'label' in df.columns:
        features_select = features_select + ['label']
        
    df = df.select(*features_select).distinct()
    df = df.dropDuplicates(['assetid', 'incident_start_date'])
    
    
    # Persist predictions
    print('Data Processing Stage is finished and writing to HDFS..')

    if df.rdd.isEmpty():
        print("Processed Dataframe is empty")
    else:
        df.write.format("parquet").mode('overwrite').save(config["paths_post_stage5"]['all_model'])
        return df
        

def main_stage5(asset_id):
    '''
    This is a main function for Stage 5
    
    Args:
        args (list) : List of arguments

    '''
    
    # start Spark application and get Spark session, logger and config
    spark, config = start_spark(app_name='repeateds_stage5')

    # Cleaning the memory
    print('cleaning memory...')
    spark.catalog.clearCache()

    # Enter Code here 
    df = stage5(spark, config)

    # log the success and terminate Spark application
    print('\n\nModel Prediction as follows ...\n')
    df.filter("assetid = '{}'".format(asset_id)).show()

