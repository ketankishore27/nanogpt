import sys
from jobs.stage1 import main_stage1
from jobs.stage4 import main_stage4
from jobs.stage5 import main_stage5



if __name__ == '__main__':
    args = sys.argv
    print(args)
    asset_id = args[4].split('=')[-1].strip()
    pipeline_mode = args[1].split('=')[-1].strip()
    solution_level = args[2].split('=')[-1].strip()
    pipeline_refresh = args[3].split('=')[-1].strip()

    if eval(pipeline_refresh):
        main_stage1(pipeline_mode, solution_level)
        main_stage4()

    main_stage5(asset_id)


## python local_inference.py --pipeline_mode='Inference' --solution_level='L2_L3' --pipeline_refresh=False --asset_id='49520006'





