cfg = {
    "spark_session": {
        "app_name": "repeated_faults",
        "master": "yarn"
    },

    "history": {
        "init": "true"
    },

    "db": {
        "raw_db_xsdl": "cdl_acscoll",
        "raw_db_pol_day": "cdl_blos",
        "raw_db_wifi": "cdl_acscoll",
        "raw_pol_day_table": "pol_day_aggregation",
        "raw_xsdl_table": "cdl_acscoll_xdsl_line_prq",
        "raw_snmp_table": "snmp_traps_agg",
        "raw_wifi_table": "cdl_acscoll_wifi_params_prq",
        'tickets': "cdl_tdata_cpe.cdl_tdata_cpe_tickets_011021_010722"

    },

    "paths_post_stage1": {
        "all_model": "hdfs://nameservicedev1//user/tsystems_kkeshore/repeated_faults/stage_1/data_source"
    },

    "paths_post_stage2": {
        "all_model": "hdfs://nameservicedev1//user/tsystems_kkeshore/repeated_faults/stage_2/data_source",
    },

    "paths_post_stage3": {
        "all_model": "hdfs://nameservicedev1//user/tsystems_kkeshore/repeated_faults/stage_3/data_source",
    },

    "paths_post_stage4": {
        "all_model": "hdfs://nameservicedev1//user/tsystems_kkeshore/repeated_faults/stage_4/data_source",
    },

    "paths_post_stage5": {
        "W7": "",
        "HA35": "",
        "Speedport": "",
        "ZXDSL": "",
    },

    "paths_post_stage6": {
        "overall_predictions": "",
        "recommendations": "",
    },

    "paths_post_stage7": {
        "raw_counts": "",
        "data_drift": "",
        "funnel": "",
        "recommendation_stats": "",
    },

    'inventory_creation': {

        'followup_duration': 30,
        'stage_data_type': {

            'string_type': {
                'columns': ['assetid', 'ticket_id', 'summary', 'normalised_summary'],
                'format': ''
            },

            'datetype': {
                'columns': ['start_date', 'complaint_process_end_date'],
                'format': 'yyyyMMdd'
            }

        },
        'normalise_summary': {

            'dsl': ['dsl'],
            'telephone_line': ['tel. signal', 'stalno', 'zauzet', 'poziv'],
            'cpe_fault': ['boot', 'modem'],
            'iptv': ['slike', 'iptv', 'stb'],
            'internet_degrade': ['brzinom', 'internet'],
            'dth': ['dth', 'dtx'],
            'gpon_issue': ['optika'],
            'inhouse_installation': ['instalacij']
        },
        'ticket_categories': ['dsl', 'cpe_fault', 'iptv', 'internet_degrade']
    },

    "data_preprocessing": {

        "window_before": 5,
        "window_after": 5,
        "gap_before": 0,
        "gap_after": 0,

        "trend": {
            "window_min": 2,
            "window_max": 5,
        },

        "max_time": 6,

        "feature_operation": {

            "numerical": ['dslam_distinct_modulation', 'dslam_no_of_dominant_modulation',
                          'dslam_code_of_dominant_modulation', 'dslam_avg_bitrate_us', 'dslam_max_bitrate_us',
                          'dslam_min_bitrate_us', 'dslam_avg_bitrate_ds', 'dslam_max_bitrate_ds',
                          'dslam_min_bitrate_ds', 'dslam_avg_attenuation_ds', 'dslam_max_attenuation_ds',
                          'dslam_min_attenuation_ds', 'dslam_avg_attenuation_us', 'dslam_max_attenuation_us',
                          'dslam_min_attenuation_us', 'dslam_avg_power_us', 'dslam_max_power_us', 'dslam_min_power_us',
                          'dslam_avg_power_ds', 'dslam_max_power_ds', 'dslam_min_power_ds', 'dslam_avg_att_bitrate_us',
                          'dslam_max_att_bitrate_us', 'dslam_min_att_bitrate_us', 'dslam_avg_att_bitrate_ds',
                          'dslam_max_att_bitrate_ds', 'dslam_min_att_bitrate_ds', 'dslam_avg_snr_us',
                          'dslam_max_snr_us', 'dslam_min_snr_us', 'dslam_avg_snr_ds', 'dslam_max_snr_ds',
                          'dslam_min_snr_ds', 'dslam_no_counts', 'dslam_avg_bandline_ds', 'dslam_max_bandline_ds',
                          'dslam_min_bandline_ds', 'dslam_avg_bandline_us', 'dslam_max_bandline_us',
                          'dslam_min_bandline_us', 'dslam_avg_net_datarate_ds', 'dslam_max_net_datarate_ds',
                          'dslam_min_net_datarate_ds', 'dslam_avg_net_datarate_us', 'dslam_max_net_datarate_us',
                          'dslam_min_net_datarate_us', 'dslam_sum_cv_us', 'dslam_count_cv_us', 'dslam_sum_cv_ds',
                          'dslam_count_cv_ds', 'dslam_sum_es_ds', 'dslam_count_es_ds', 'dslam_sum_es_us',
                          'dslam_count_es_us', 'dslam_sum_ses_ds', 'dslam_count_ses_ds', 'dslam_sum_ses_us',
                          'dslam_count_ses_us', 'dslam_sum_fec_ds', 'dslam_count_fec_ds', 'dslam_sum_fec_us',
                          'dslam_count_fec_us', 'dslam_inits', 'snmp_total_count', 'snmp_no_lossoflink',
                          'snmp_no_linkup', 'snmp_no_dyinggasp', 'acs_xdslline_dslUptime', 'acs_xdslline_cpeUptime',
                          'acs_xdslline_cellDelinDelta_sum', 'acs_xdslline_erroredSecsDelta_sum',
                          'acs_xdslline_initErrorsDelta_sum', 'acs_xdslline_initTimeoutsDelta_sum',
                          'acs_xdslline_severelyErroredSecsDelta_sum', 'acs_xdslline_linkRetrainDelta_sum',
                          'acs_xdslline_lossOfFramingDelta_sum', 'acs_xdslline_transmitBlocksDelta_sum',
                          'acs_xdslline_receiveBlocksDelta_sum', 'acs_xdslline_atuccrcdelta_sum',
                          'acs_xdslline_atucfecdelta_sum', 'acs_xdslline_atuchecdelta_sum', 'acs_xdslline_crcdelta_sum',
                          'acs_xdslline_fecdelta_sum', 'acs_xdslline_hecdelta_sum',
                          'acs_xdslline_cpuUsagePercentage_min', 'acs_xdslline_freeMemoryKb_min',
                          'acs_xdslline_totalMemoryKb_min', 'acs_xdslline_usedMemoryKb_min',
                          'acs_xdslline_natCurrent_min', 'acs_xdslline_natMax_min',
                          'acs_xdslline_downAttenuationDb_min', 'acs_xdslline_downCurrRateKbps_min',
                          'acs_xdslline_downMaxRateKbps_min', 'acs_xdslline_downNoiseMarginDb_min',
                          'acs_xdslline_downPowerDbm_min', 'acs_xdslline_upAttenuationDb_min',
                          'acs_xdslline_upCurrRateKbps_min', 'acs_xdslline_upMaxRateKbps_min',
                          'acs_xdslline_upNoiseMarginDb_min', 'acs_xdslline_upPowerDbm_min',
                          'acs_xdslline_cpuUsagePercentage_max', 'acs_xdslline_freeMemoryKb_max',
                          'acs_xdslline_totalMemoryKb_max', 'acs_xdslline_usedMemoryKb_max',
                          'acs_xdslline_natCurrent_max', 'acs_xdslline_natMax_max',
                          'acs_xdslline_downAttenuationDb_max', 'acs_xdslline_downCurrRateKbps_max',
                          'acs_xdslline_downMaxRateKbps_max', 'acs_xdslline_downNoiseMarginDb_max',
                          'acs_xdslline_downPowerDbm_max', 'acs_xdslline_upAttenuationDb_max',
                          'acs_xdslline_upCurrRateKbps_max', 'acs_xdslline_upMaxRateKbps_max',
                          'acs_xdslline_upNoiseMarginDb_max', 'acs_xdslline_upPowerDbm_max',
                          'acs_xdslline_cpuUsagePercentage_avg', 'acs_xdslline_freeMemoryKb_avg',
                          'acs_xdslline_totalMemoryKb_avg', 'acs_xdslline_usedMemoryKb_avg',
                          'acs_xdslline_natCurrent_avg', 'acs_xdslline_natMax_avg',
                          'acs_xdslline_downAttenuationDb_avg', 'acs_xdslline_downCurrRateKbps_avg',
                          'acs_xdslline_downMaxRateKbps_avg', 'acs_xdslline_downNoiseMarginDb_avg',
                          'acs_xdslline_downPowerDbm_avg', 'acs_xdslline_upAttenuationDb_avg',
                          'acs_xdslline_upCurrRateKbps_avg', 'acs_xdslline_upMaxRateKbps_avg',
                          'acs_xdslline_upNoiseMarginDb_avg', 'acs_xdslline_upPowerDbm_avg',
                          'acs_xdslline_atuccrcdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_atucfecdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_atuchecdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_crcdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_fecdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_hecdelta_sum_acs_xdslline_transmitBlocksDelta_sum_ratio',
                          'acs_xdslline_atuccrcdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_atucfecdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_atuchecdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_crcdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_fecdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_hecdelta_sum_acs_xdslline_receiveBlocksDelta_sum_ratio',
                          'acs_xdslline_usedMemoryKb_min_acs_xdslline_totalMemoryKb_avg_ratio',
                          'acs_xdslline_usedMemoryKb_avg_acs_xdslline_totalMemoryKb_avg_ratio',
                          'acs_xdslline_usedMemoryKb_max_acs_xdslline_totalMemoryKb_avg_ratio',
                          'acs_xdslline_dslUptime_restart', 'acs_xdslline_cpeUptime_restart',
                          'acs_transmissions_acs_count'],
            "categorical": ['dslam_platforma', 'dslam_internet', 'dslam_iptv', 'dslam_voip', 'dslam_card_type',
                            'dslam_status_porta', 'dslam_vdsl_adsl', 'normalised_summary'],
        }
    },

    "data_gathering": {
        "seq_len": 5,
        "gap": 0,
        "days_consider": 2,
        "column_nulls": "dslam_avg_attenuation_ds",
        "features": {
            "dslam": {
                "measurements": ['dslam_distinct_modulation', 'dslam_no_of_dominant_modulation',
                                 'dslam_code_of_dominant_modulation',
                                 'dslam_avg_bitrate_us', 'dslam_max_bitrate_us', 'dslam_min_bitrate_us',
                                 'dslam_avg_bitrate_ds',
                                 'dslam_max_bitrate_ds', 'dslam_min_bitrate_ds', 'dslam_avg_attenuation_ds',
                                 'dslam_max_attenuation_ds',
                                 'dslam_min_attenuation_ds', 'dslam_avg_attenuation_us', 'dslam_max_attenuation_us',
                                 'dslam_min_attenuation_us',
                                 'dslam_avg_power_us', 'dslam_max_power_us', 'dslam_min_power_us', 'dslam_avg_power_ds',
                                 'dslam_max_power_ds',
                                 'dslam_min_power_ds', 'dslam_avg_att_bitrate_us', 'dslam_max_att_bitrate_us',
                                 'dslam_min_att_bitrate_us',
                                 'dslam_avg_att_bitrate_ds', 'dslam_max_att_bitrate_ds', 'dslam_min_att_bitrate_ds',
                                 'dslam_avg_snr_us',
                                 'dslam_max_snr_us', 'dslam_min_snr_us', 'dslam_avg_snr_ds', 'dslam_max_snr_ds',
                                 'dslam_min_snr_ds',
                                 'dslam_no_counts', 'dslam_avg_bandline_ds', 'dslam_max_bandline_ds',
                                 'dslam_min_bandline_ds',
                                 'dslam_avg_bandline_us', 'dslam_max_bandline_us', 'dslam_min_bandline_us',
                                 'dslam_avg_net_datarate_ds',
                                 'dslam_max_net_datarate_ds', 'dslam_min_net_datarate_ds', 'dslam_avg_net_datarate_us',
                                 'dslam_max_net_datarate_us',
                                 'dslam_min_net_datarate_us', 'dslam_sum_cv_us', 'dslam_count_cv_us', 'dslam_sum_cv_ds',
                                 'dslam_count_cv_ds',
                                 'dslam_sum_es_ds', 'dslam_count_es_ds', 'dslam_sum_es_us', 'dslam_count_es_us',
                                 'dslam_sum_ses_ds',
                                 'dslam_count_ses_ds', 'dslam_sum_ses_us', 'dslam_count_ses_us', 'dslam_sum_fec_ds',
                                 'dslam_count_fec_ds',
                                 'dslam_sum_fec_us', 'dslam_count_fec_us', 'dslam_inits'],

                "categoricals": ['dslam_platforma', 'dslam_model', 'dslam_card_type', 'dslam_status_porta',
                                 'dslam_vdsl_adsl', 'dslam_status',
                                 'dslam_internet', 'dslam_iptv', 'dslam_voip', 'dslam_servis', 'dslam_em_profil'],

                "grouping_features": ["dslam_assetid", "dslam_datum"]
            },

            "snmp": {
                "measurements": ["snmp_total_count", "snmp_no_lossoflink", "snmp_no_linkup", "snmp_no_dyinggasp"],
                "grouping_features": ["snmp_assetid", "snmp_datum"]
            },

            "acs": {
                "grouping_features": ["acs_assetid",
                                      "acs_datum"],

                "categorical": ["acs_crm_productClass",
                                "acs_xdslline_softwareVersion"],

                "incremental": ["acs_xdslline_dslUptime",
                                "acs_xdslline_cpeUptime"],

                "delta": ["acs_xdslline_cellDelinDelta",
                          "acs_xdslline_erroredSecsDelta",
                          "acs_xdslline_initErrorsDelta",
                          "acs_xdslline_initTimeoutsDelta",
                          "acs_xdslline_severelyErroredSecsDelta",
                          "acs_xdslline_linkRetrainDelta",
                          "acs_xdslline_lossOfFramingDelta",
                          "acs_xdslline_transmitBlocksDelta",
                          "acs_xdslline_receiveBlocksDelta",
                          "acs_xdslline_atuccrcdelta",
                          "acs_xdslline_atucfecdelta",
                          "acs_xdslline_atuchecdelta",
                          "acs_xdslline_crcdelta",
                          "acs_xdslline_fecdelta",
                          "acs_xdslline_hecdelta"],

                "measurements": ["acs_xdslline_cpuUsagePercentage",
                                 "acs_xdslline_freeMemoryKb",
                                 "acs_xdslline_totalMemoryKb",
                                 "acs_xdslline_usedMemoryKb",
                                 "acs_xdslline_natCurrent",
                                 "acs_xdslline_natMax",
                                 "acs_xdslline_downAttenuationDb",
                                 "acs_xdslline_downCurrRateKbps",
                                 "acs_xdslline_downMaxRateKbps",
                                 "acs_xdslline_downNoiseMarginDb",
                                 "acs_xdslline_downPowerDbm",
                                 "acs_xdslline_upAttenuationDb",
                                 "acs_xdslline_upCurrRateKbps",
                                 "acs_xdslline_upMaxRateKbps",
                                 "acs_xdslline_upNoiseMarginDb",
                                 "acs_xdslline_upPowerDbm"],

            },
        },
    },

    "paths_models": {
        "W7": "",
        "HA35": "",
        "Speedport": "",
        "ZXDSL": "",
    },

    "model": {
        "W7": {
            "model_tag_1": "",
            "model_tag_2": "",
            "ensemble": {
                "weights": []
            },
        },

        "HA35": {
            "model_tag_1": "",
            "model_tag_2": "",
            "ensemble": {
                "weights": []
            },
        },

        "Speedport": {
            "model_tag_1": "",
            "model_tag_2": "",
            "ensemble": {
                "weights": []
            },
        },

        "ZXDSL": {
            "model_tag_1": "",
            "model_tag_2": "",
            "ensemble": {
                "weights": []
            },
        },
    },

    "reset_budget": {
        "W7": 0,
        "HA35": 0,
        "Speedport": 0,
        "ZXDSL": 0,
    },

    "control_group": {
        "A": 0.5,
        "B": 0.5,

    },

    "kafka": {
        "reboot_req": {
            "botstrap_servers": "lxcdhkafkav1d.dc.ht.hr:9092,lxcdhkafkav2d.dc.ht.hr:9092,lxcdhkafkav3d.dc.ht.hr:9092",
            "topic": "REPEATED_FAULTS"
        },

    }
}