import pyspark.sql.functions as F
from datetime import timedelta,date
from datetime import datetime, timedelta
import datetime as dt
from pyspark.sql.types import StringType,DateType
from dependencies.utils import * 
from dependencies.batch_id_update_utils import *
from pyspark.sql.window import Window

def select_top_k(df,cpe_type,config,spark):
    '''
    This function is to get the top k prediction
    
    Args:
        df (dataframe): Predicted dataframe.
        cpe_type (str) : CPE Type.
        config (dict) : Configuration dictionary.

    Returns:
        df_top_k (dataframe) : Output dataframe
    '''
    
    df_filtered_cpes= filter_locked_cpe(df,config,spark)
    df_sorted = df_filtered_cpes.sort(F.col("probability_1").desc())
    df_top_k = df_sorted.limit(config['reset_budget'][cpe_type])
    df_filtered = df_top_k.withColumn('index', F.monotonically_increasing_id())
    windowSpec = Window.orderBy("index")
    df_filtered = df_filtered.withColumn("idx", F.row_number().over(windowSpec))
    df_filtered = df_filtered.drop('index')
 
    return df_filtered

def filter_locked_cpe(df,config,spark):
    '''
    This function is to remove last 7 days of recommendations

    Args:
        df (dataframe): Predicted dataframe.
        config (dict) : Configuration dictionary.
        spark : spark

    Returns:
        df_top_k (dataframe) : Output dataframe
    '''
    start_date, end_date = time_duration(config['timedeltas']['gap_incident_date'], 7)
    print(start_date,end_date)
    df_blocked_cpe = spark.sql("SELECT assetid,event_date FROM {0} WHERE event_date BETWEEN '{1}' and '{2}'".format(config['paths_post_stage6']['recommendations'],start_date,end_date))
    print("SELECT assetid,event_date FROM {0} WHERE event_date BETWEEN '{1}' and '{2}'".format(config['paths_post_stage6']['recommendations'],start_date,end_date))
    df_blocked_cpe = df_blocked_cpe.withColumn('assetid', F.col('assetid').cast('string'))
    df_blocked_cpe = df_blocked_cpe.dropDuplicates(['assetid','event_date'])
    df = df.withColumn('assetid', F.col('assetid').cast('string'))
    df = df.dropDuplicates(['assetid','event_date'])
    df_filtered = df.join(df_blocked_cpe, on = 'assetid', how = 'left_anti')

    return df_filtered

# def create_control_group(df):
#     '''
#     This function is to create different control group for A/B testing
#
#     Args:
#         df (dataframe): Predicted dataframe.
#
#     Returns:
#         df_A (dataframe) : Output dataframe
#         df_B (dataframe) : Output dataframe
#     '''
#
#     df = df.withColumn('testing_group',F.when(F.col('idx')%2==0,'B').otherwise('A'))
#     df = df.drop('idx')
#     df_A = df.filter(F.col('testing_group')=='A')
#     df_B = df.filter(F.col('testing_group') == 'B')
#
#
#     return df_A, df_B

def create_control_group(df,config, cpe_type,spark):
    '''
    This function is to create different control group for A/B testing

    Args:
        df (dataframe): Predicted dataframe.
        config (dict) : Configuration dictionary.
        cpe_type (str) : prduct class
        spark : spark

    Returns:
        df_A (dataframe) : Output dataframe
        df_B (dataframe) : Output dataframe
    '''

    if (cpe_type == cpe_type):
        df_A = spark.read.parquet(config['paths_inventory'][cpe_type]['A'])
        df_B = spark.read.parquet(config['paths_inventory'][cpe_type]['B'])
        df_A = df.join(df_A, on=['assetid'], how='inner')
        df_B = df.join(df_B, on=['assetid'], how='inner')

    return df_A, df_B


def kpi_inference_format(df, cpe_type, args):
    '''
    Function to format the Scored data

    Args:
        df (dataframe) : input dataframe
        cpe_type (str) : string
        args (str) : Arguments

    Returns:
        df (dataframe) : Output dataframe
    '''
    df = add_batch_id(df, get_batch_id(args))
    df = df.withColumnRenamed('batchid', 'dag_run_id')
    df = df.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df = add_time(df, get_time(args))
    df = df.withColumn('cpe_type', F.lit(cpe_type))
    df = df.withColumnRenamed('incident_date', 'event_date')
    df = df.withColumn('assetid', F.col('assetid').cast('string'))
    df = df.withColumnRenamed('probability_ensamble', 'probability_1')
    df = df.withColumn("networkdeviceid", F.lit('SerialNumber'))
    cols = ['assetid', 'cpe_type', 'probability_1', 'dag_run_id', 'timestamp', 'networkdeviceid', 'event_date']
    df = df.select(*cols).distinct()
    df = df.dropDuplicates()

    return df

def recommendation_format(df):
    '''
    Function to format the Recommendation data
    
    Args:
        df (dataframe) : input dataframe
    Returns:
        df (dataframe) : Output dataframe
    '''

    df = df.withColumn("recommendation_id", F.concat(F.col('dag_run_id'), \
                                                                F.lit("_"), \
                                                                F.col('assetid'))) 
    df = df.withColumn("timestamp",F.col("timestamp").cast(types.TimestampType()))
    cols = ['recommendation_id','assetid','cpe_type','probability_1','dag_run_id','timestamp','networkdeviceid','testing_group','event_date']
    df = df.select(*cols).distinct()
    df = df.dropDuplicates()

    return df

def write_batch_on_kafka(df, config):
    """
    This function writes in a specific kafka topic.

    Args:
        df (dataframe): Input data.
        config (json): Configuration dictionary.
    """
    df.select(F.to_json(F.struct(*df.columns)).alias("value")) \
        .write.format("kafka") \
        .option("kafka.bootstrap.servers", config['kafka']['repeated_req']['botstrap_servers']) \
        .option("topic", config['kafka']['repeated_req']['topic']) \
        .option("kafka.security.protocol", "SASL_PLAINTEXT") \
        .option('kafka.sasl.mechanism','GSSAPI') \
        .option('kafka.sasl.kerberos.service.name', 'kafka') \
        .save()


def kafka_format(df):
    '''
    This function is to match the desired Kafka format 
    
    Args:
        df (dataframe): Predicted dataframe.

    Returns:
        df (dataframe) : Output dataframe
    '''

    df = df.withColumn("diagnosticsRuntime",F.col("timestamp"))\
                                                .withColumn("cpeSerialNumber",  F.lit('SerialNumber'))\
                                                .withColumn("uniqueIdOfRecommendation", F.col('recommendation_id'))\
                                                .withColumn("cpeSoftwareVersion", F.lit('0.0'))\
                                                .withColumn("scoring", F.col('probability_1'))\
                                                .withColumn("model_id", F.lit('cpe_repeated'))\
                                                .withColumn("actionId", F.lit('201'))\
                                                .withColumn("cpeModelName", F.col('cpe_type'))
    
    # Final df based on new message structure for Kafka cpe_repeated_req topic 
    df = df.withColumnRenamed('assetid', 'asset_id')

    df = df.withColumn('asset_id', df["asset_id"].cast(StringType()))
    df = df.withColumn('scoring', df["scoring"].cast(StringType()))

    df = df.select('asset_id', 
                   'diagnosticsRuntime',
                   'uniqueIdOfRecommendation',
                   'cpeSerialNumber',
                   'cpeModelName',
                   'cpeSoftwareVersion',
                   'scoring',
                   'model_id')

    return df
