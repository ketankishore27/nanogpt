from pyspark.sql import functions as F



def clipper_transform(df, features_indexed, clip):
    '''
    This function restict the number of maximun indexed categories for each one of the features listed.

    Args:
        df (dataframe): Input dataframe with unrestricted unique indexed values per categorical features.
        features_indexed (list[str]): list of categorical features indexed.
        clip (int): max number of indexed categories allowed.

    Return:
        df (dataframe): Output Dataframe
    '''
    for feature in features_indexed:
        df = df.withColumn(feature, F.when(F.col(feature) < clip, F.col(feature)).otherwise(clip))

    return df


def extract_internet_pack(df):
    '''
    This function extract Internet pack opted by the users.

    Args:
        df (dataframe): Input dataframe

    Return:
        df (dataframe): Output Dataframe
    '''
    df = df.withColumn('internet_pack', F.substring('dslam_servis', 1, 14))
    df = df.withColumn("internet_pack", F.regexp_replace(F.col("internet_pack"), "[^a-zA-Z0-9_]", ""))
    df = df.withColumn('internet_pack',
                       F.when(F.col('internet_pack').contains('INTERNET'), F.col('internet_pack')).otherwise(
                           'no_internet'))

    return df


def handle_nulls(df, config):
    '''
    This function fill null values

    Args:
        df (dataframe): Input dataframe with

    Return:
        df (dataframe): Output Dataframe
    '''
    # Filling Null values for Categorical features
    df = df.fillna('unknown', subset=config["data_preprocessing"]["feature_operation"]["categorical"])
    # Filling Null values for Numerical features
    df = df.fillna(-1.0)

    return df