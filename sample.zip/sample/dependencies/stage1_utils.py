from datetime import datetime, timedelta
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from dependencies.utils import *
from dependencies.config import cfg as config


def extract_raw_tickets(spark, config, solution_level=None, log=None):
    """
    This function is for extracting  raw tickets

    Args:
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        df_filtered (dataframe) : Output dataframe consists of the tickets data
    """
    section_header("Extract Raw Tickets")
    normalise_summary_udf = F.udf(normalise_summary, StringType())
    tickets = spark.read.csv(r"data/all_Tickets_filtered.csv", header=True) \
        .drop_duplicates(['ticket_id']) \
        .withColumn("solution_level", F.col("solution_level").cast(IntegerType())) \
        .withColumn("solution_level", F.concat(F.lit("L"), F.col("solution_level").cast(StringType()))) \
        .withColumn("normalised_summary", normalise_summary_udf(F.col('summary'))) \
        .filter("solution_level in {} and normalised_summary in {}".format(str(tuple(solution_level.split('_'))), \
                                                                           str(tuple(config['inventory_creation']['ticket_categories'])))) \
        .filter("asset_id != -999 and asset_id != 0") \
        .withColumnRenamed('asset_id', 'assetid') \
        .withColumn('assetid', F.col('assetid').cast(IntegerType())) \
        .withColumn('ticket_id', F.col('ticket_id').cast(IntegerType())) \
        .select(['assetid', 'start_date', 'complaint_process_end_date', 'summary', 'ticket_id', 'normalised_summary'])

    tickets = datatype_check(tickets, 'inventory_creation', spark, log, config)
    return tickets


def normalise_summary(sample):

    if sample:
        sample = sample.lower()
        for key in config['inventory_creation']['normalise_summary'].keys():
            for val in config['inventory_creation']['normalise_summary'][key]:
                if val in sample:
                    return key
        return 'others'
    else:
        return sample


def datatype_check(df, stage, spark, log, config):
    """
    This function ensures datatype integrity

    Args:
        df(object) : Output Dataframe
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        df_filtered (dataframe) : Output dataframe consists of the tickets data with proper datatype
    """
    section_header("Data Type Check")
    columns_processed = []
    for key in config[stage]['stage_data_type'].keys():
        if key == 'datetype':
            format_desc = config[stage]['stage_data_type'][key]['format']
            for col in config[stage]['stage_data_type'][key]['columns']:
                df = df.withColumn(col, F.to_date(F.col(col), format_desc))
                columns_processed.append(col)

        if key == 'string_type':
            for col in config[stage]['stage_data_type'][key]['columns']:
                df = df.withColumn(col, F.col(col).cast(StringType()))
                columns_processed.append(col)

    float_cols = [i for i in df.columns if not i in columns_processed]
    for col in float_cols:
        df = df.withColumn(col, F.col(col).cast(DoubleType()))

    return df


def alias_frames(df, spark, version, log=None):
    """
    This function is used to create seperate dataframe.
    This is required because when we do a self join we dont want duplicates features.
    Also follow up tickets can have different attributes in the features

    Args:
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        df_filtered (dataframe) : Output dataframe consists of aliased dataframe
    """
    section_header("Frame Alias")
    for col in df.columns:
        df = df.withColumnRenamed(col, col + str(version))
    return df


def create_followup_tickets(df1, df2, spark, config, log=None):
    """
    This function creates tickets which occured as a followup
    Args:
        df1, df2(object): Same dataframe but aliased differntly
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        df_filtered (dataframe) : Output dataframe consists followup tickets
    """
    section_header("Create Followup tickets")
    data_joined = df1.join(df2,
                           on=[
                               (df1['assetid1'] == df2['assetid2']) &
                               (
                                       (F.datediff(df2['start_date2'], df1['complaint_process_end_date1']) >= 0) &
                                       (F.datediff(df2['start_date2'], df1['complaint_process_end_date1']) <=
                                        config['inventory_creation']['followup_duration']) &
                                       (df1['complaint_process_end_date1'] < df2['start_date2'])
                               )
                           ],
                           how='inner')

    data_joined = data_joined.withColumn("date_diff",
                                         F.datediff(F.col('start_date2'), F.col('complaint_process_end_date1')))
    window = Window.partitionBy('ticket_id1').orderBy(F.col('date_diff'))
    data_joined = data_joined.withColumn("Ranks", F.rank().over(window)).filter("Ranks = 1")
    data_assetid = data_joined.groupBy('assetid2').count().filter("count >= 1 and count <= 30").select("assetid2")
    return data_joined.join(data_assetid, on=['assetid2'], how='inner') \
        .withColumn('incident_start_date',
                    F.when(F.col('start_date1') < F.col('start_date2'), F.col('start_date1')).otherwise(
                        F.col('start_date2'))) \
        .withColumn('incident_end_date',
                    F.when(F.col('complaint_process_end_date1') < F.col('complaint_process_end_date2'),
                           F.col('complaint_process_end_date1')).otherwise(F.col('complaint_process_end_date2'))) \
        .withColumn("label", F.lit(1)) \
        .withColumnRenamed('assetid1', 'assetid') \
        .withColumnRenamed('ticket_id1', 'ticket_id') \
        .withColumnRenamed('summary1', 'summary') \
        .withColumnRenamed('normalised_summary1', 'normalised_summary') \
        .withColumn("label", F.lit(1)) \
        .select(['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id', 'summary', 'normalised_summary', 'label'])


def create_nofollowup_ticket(df, spark, config, log=None):
    """
    This function creates tickets which did not occur as a followup
    Args:
        df (object): Same dataframe but aliased differntly
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        df_filtered (dataframe) : Output dataframe consists no followup tickets
    """
    section_header("Create no followup tickets")
    data_uniqueTickets = df.groupBy('assetid').count().filter('count == 1').select('assetid')
    df = df.select(
        ['assetid', 'start_date', 'complaint_process_end_date', 'ticket_id', 'summary', 'normalised_summary']) \
        .withColumnRenamed('start_date', 'incident_start_date') \
        .withColumnRenamed('complaint_process_end_date', 'incident_end_date')
    data_inventory_healthy = df.join(data_uniqueTickets, on=['assetid'], how='inner')
    data_inventory_healthy = data_inventory_healthy.withColumn("label", F.lit(0))
    return data_inventory_healthy


def get_inference_data(spark, config, solution_lvl, log=None):
    """
    This function creates tickets should be taken at the inference time
    Args:
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary

    Returns:
        filtered_ticket (dataframe) : Output dataframe consists of tickets to be predicted at inference time
    """
    cycle_date = datetime.strptime('2022-03-15', '%Y-%m-%d')  # datetime.now().date()  #to_change
    reference_date = (cycle_date - timedelta(
        days=config['data_preprocessing']['window_after'] + config['data_preprocessing']['gap_after'])).date()
    current_ticket = extract_raw_tickets(spark, config, solution_lvl, log=log).filter(
        "complaint_process_end_date = '{}'".format(str(reference_date)))
    tickets_to_filter = extract_raw_tickets(spark, config, solution_lvl, log=log).filter(
        "start_date > '{}' and start_date <= '{}'".format(str(reference_date), str(cycle_date.date())))
    filtered_ticket = current_ticket.join(tickets_to_filter, on=['assetid'], how='left_anti') \
        .withColumnRenamed('start_date', 'incident_start_date') \
        .withColumnRenamed('complaint_process_end_date', 'incident_end_date')
    print("Ticket Before filtering: {}, After filtering: {}".format(current_ticket.count(), filtered_ticket.count()))
    print("Reference_date: {}, Cycle_date: {}".format(reference_date, cycle_date.date()))
    return filtered_ticket