# Data Science Packages
import sys
from datetime import datetime, timedelta
#Spark Packages
import pyspark.sql.functions as F
from pyspark.sql.types import *
from pyspark.sql.window import Window
from dependencies.utils import *

def get_dates(df,config):
    
    """Get Start and End dates from inventory list
    
    Args:
        df (dataframe): Input spark df.
    Returns:
        start_time(string): start date from the inventory
        end_time(string): end date from the inventory
    """ 
    section_header("Get Dates")
    start_time, end_time = df.select(F.min("incident_start_date"), F.max("incident_end_date")).first()
    start_time = get_window_start(start_time, config["data_gathering"]["gap"]+config["data_gathering"]["seq_len"])
    end_time = get_window_end(end_time, config)
    
    return start_time, end_time


def get_window_start(event_dt, window_plus_gap):
    """Function to extract the prediction gap plus the window of historical data
    to the date in which the ticket was raised.
    
    Arg:
        event_dt (str): Date in which the ticket was raise
        window_plus_gap (int): Prediction gap plus window of historical data in days.
    
    Returns:
        str: date of the window start.
    
    """
    section_header("Get Window Start")
    event_dt = datetime.strptime(str(event_dt), "%Y-%m-%d").date()
    start_time_dt = (event_dt - timedelta(days=window_plus_gap+30))
    start_time = start_time_dt.strftime("%Y-%m-%d")
    return start_time


def get_window_end(event_dt, config):
    """Function to extrat the prediction gap to the date in which the ticket was raise.
    
    Arg:
        event_dt (str): Date in which the ticket was raise
        prediction_gap (int): Predction gap in days.
    
    Returns:
        str: date of the window end.
    
    """
    section_header("Get Window End")
    event_dt = datetime.strptime(str(event_dt), "%Y-%m-%d").date()
    end_time_dt = event_dt + timedelta(days=config["data_gathering"]["gap"]+30)
    end_time = end_time_dt.strftime("%Y-%m-%d")
    return end_time

def generate_date_series(start, stop):
    """Fuction to series of date between start date and stop date.
    
    Args:
        start (timestamp): Date in original format. expected "%Y-%m-%d".
        stop (timestamp): Desire date format e.g "%Y%m%d".
    
    Returns
        List: List of all dates between the start and stop.
    """
    #section_header("Generate Date Series")
    return [start + timedelta(days=x) for x in range(0, (stop-start).days + 1)] 

def create_dates(df, spark, config):
    """
    Function to create a sequence of dates. Each assetid contains 32 different date based on the incident date provided from the Stage-1.
    
    Arg:
        df (dataframe): Dataframe, which contains the assetid that needs to be processed
        config (dict): Dictionary containing the parameters.
    
    Returns:
        df_key: Processed dataframe with assetid and sequence of 32 dates against each assetid.
        
    """
    section_header("Create Dates")
    spark.udf.register("generate_date_series", generate_date_series, ArrayType(DateType()))
    df = df.dropDuplicates(['assetid', "incident_start_date", "incident_end_date", "ticket_id"])
    # Calculate dates for before start_date
    df_before = df.withColumn('end_date', F.expr("date_sub(incident_start_date,{})".format(config['data_preprocessing']['gap_before'])))\
                  .withColumn('start_date', F.expr("date_sub(end_date,{})".format(config['data_preprocessing']['window_before'])))
    df_before.createOrReplaceTempView("keydf_before")
    df_key_before = spark.sql("SELECT assetid, incident_start_date, incident_end_date, ticket_id, normalised_summary, explode(generate_date_series(start_date, end_date)) as date FROM keydf_before")\
                         .withColumn("Flag", F.lit("Before"))
    
    # Calculate dates after the end_date
    df_after = df.withColumn('end_date', F.expr("date_add(incident_end_date,{})".format(config['data_preprocessing']['gap_after'])))\
                 .withColumn('start_date', F.expr("date_add(end_date,{})".format(config['data_preprocessing']['window_after'])))
    df_after.createOrReplaceTempView("keydf_after")
    df_key_after = spark.sql("SELECT assetid, incident_start_date, incident_end_date, ticket_id, normalised_summary, explode(generate_date_series(end_date, start_date)) as date FROM keydf_after")\
                         .withColumn("Flag", F.lit("After"))
    return df_key_before.union(df_key_after).withColumn("assetid", F.col("assetid").cast(StringType()))

def flatten_df(df):
    """This funtion flat a nested dataframe.
    
    Args:
        df (dataframe): Input nested dataframe.
        
    Returns:
        flat_df (dataframe): Output flatted datframe.
    """
    section_header("Flatten DF")
    flat_cols = [col[0] for col in df.dtypes if col[1][:6] != 'struct']
    nested_cols = [col[0] for col in df.dtypes if col[1][:6] == 'struct']
    flat_df = df.select(flat_cols +\
                   [F.col(root_col+'.'+nested_col).alias(root_col+'_'+nested_col)\
                    for root_col in nested_cols\
                    for nested_col in df.select(root_col+'.*').columns])
    return flat_df

def extract_data(spark, config ,database, table, date_col, feature_date, start_time, end_time):
    """Function to load data from Hive tables based on start time and end time.
    
    Args:
        date_col (string): Date column name in HIVE
        database (string): Database name in HIVE.
        table (string): Table name in HIVE.
        spark (obj): Spark session object.
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    """
    section_header("Extract Data")
    df = spark.sql("select * from {0}.{1} where to_date({2}) between '{3}' and '{4}' " \
              .format(config["db"][database], config["db"][table], date_col, start_time, end_time)) 
    df = convert_to_date(df,feature_date)
    
    return df

def dtype_matcher(df, feature_assetid, feature_date):
    """Function to convert to datetype column
    
    Args:
        df (dataframe): input spark dataframe
        feature_assetid (string): column
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    """ 
    section_header("Dtype Matcher")
    # AssetID cast to int
    df = df.dropna(subset=[feature_assetid])
    df = df.withColumn(feature_assetid, F.col(feature_assetid).cast(IntegerType()))

    return df

def rename_cols(df, prefix):
    """Column renameb by adding a prefix.
    
    Args:
        df (dataframe): Input dataframe.
        
    Returns:
        df (dataframe): Output datframe witha ppended prefix to columns.
    """
    section_header("Rename Cols")
    for feature in df.columns:
        df = df.withColumnRenamed(feature,prefix+feature)
    return df

def convert_to_date(df, feature_date):
    """Function to convert to datetype column
    
    Args:
        df (dataframe): input spark dataframe
        feature_date (string): column
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    """   
    section_header("Convert to Date")
    df = df.withColumn(feature_date, F.col(feature_date).cast(DateType()))
    
    return df

def intermediate_boost(spark, df_dslam, df_snmp, df_acs, config):
    '''
    This function persist intermediate query in HDFS to speed data gathering. 
    
    Args:
        df_dslam (dataframe): DSLAM dataset
        df_snmp (dataframe): SNMP dataset
        df_acs (dataframe): ACS dataset
        
    Returns:
        df_dslam (dataframe): DSLAM dataset
        df_snmp (dataframe): SNMP dataset
        df_acs (dataframe): ACS dataset
    '''
    section_header("Intermediate Boost")
    df_dslam.write.format("parquet").mode('overwrite').save(config["paths_post_stage2"]["all_model"] + '_boost_dslam')
    df_snmp.write.format("parquet").mode('overwrite').save(config["paths_post_stage2"]["all_model"] + '_boost_snmp')
    df_acs.write.format("parquet").mode('overwrite').save(config["paths_post_stage2"]["all_model"] + '_boost_acs')
    
    df_dslam = spark.read.parquet(config["paths_post_stage2"]["all_model"] + '_boost_dslam')
    df_snmp = spark.read.parquet(config["paths_post_stage2"]["all_model"] + '_boost_snmp')
    df_acs = spark.read.parquet(config["paths_post_stage2"]["all_model"] + '_boost_acs')
    
    return df_dslam, df_snmp, df_acs

def precheck_gather_data(spark, df_inventory,  start_time, end_time, config):
    '''
    This function is to load data from different sources
    
    Args:
        df_inventory (dataframe): Input spark dataframe
         start_time (date): Date start query 
         end_time (date): Date finish query
        
    Returns:
        df_dslam (dataframe): DSLAM dataset
        df_snmp (dataframe): SNMP dataset
        df_acs (dataframe): ACS dataset
    
    '''

    section_header("Pre Check Gather Data")
    df_key = create_dates(df_inventory, spark, config)
    df_key = rename_cols(df_key, 'key_')

    # Get DSLAM data
    df_dslam = extract_data(spark,config,'raw_db_pol_day','raw_pol_day_table','datum','datum', start_time, end_time)
    df_dslam = df_dslam.withColumn('datum', F.col('datum').cast(DateType()))
    df_dslam = df_key.join(df_dslam, [(df_key.key_assetid == df_dslam.assetid) & (df_key.key_date == df_dslam.datum)], how='inner')
    df_dslam = df_dslam.dropDuplicates()

    # Get SNMP data
    df_snmp = extract_data(spark,config,'raw_db_pol_day','raw_snmp_table','datum','datum',start_time, end_time)
    df_snmp = df_snmp.withColumn('datum', F.col('datum').cast(DateType()))
    df_snmp = df_key.join(df_snmp, [(df_key.key_assetid == df_snmp.assetid) & (df_key.key_date == df_snmp.datum)], how='inner')
    df_snmp = df_snmp.dropDuplicates()

    # Get ACS data
    df_acs = extract_data(spark,config,'raw_db_xsdl','raw_xsdl_table','datum','datum', start_time, end_time)
    df_acs = flatten_df(df_acs)
    df_acs = df_acs.withColumnRenamed('crm_assetId','assetid')
    df_acs = dtype_matcher(df_acs,'assetid','datum')
    df_acs = df_acs.withColumn('datum', F.col('datum').cast(DateType()))
    df_acs = df_key.join(df_acs, [(df_key.key_assetid == df_acs.assetid) & (df_key.key_date == df_acs.datum)], how='inner')
    df_acs = df_acs.dropDuplicates()

    return df_dslam, df_snmp, df_acs

def acs_create_incremental_features(df, config,section):
    """
    This Funtion is used to create incremental features
    
    Args:
        df (dataframe): input dataframe
        config (dict): Configuration file.
        section (string): Functionality area.
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    
    """
    section_header("ACS Incremental Features")
    window = Window.partitionBy(['key_assetid','key_incident_start_date', 'key_incident_end_date', 'key_ticket_id']).orderBy(F.col('key_date').asc())


    for col in ['xdslline_dslUptime', 'xdslline_cpeUptime']:
        df = df.withColumn(col+'_difference', (F.col(col) - F.lag(F.col(col), 1).over(window)))
        df = df.withColumn(col+'_restart', F.when(F.col(col+'_difference') < 0, 1).otherwise(0))
    
    reset_features = ['acs_xdslline_dslUptime_restart', 'acs_xdslline_cpeUptime_restart']
    return df, reset_features

def preprocess_data(df,prefix, cols_to_convert,cols):
    """
    This Funtion gather the relevant information of specific measurements.
    
    Args:
        df (dataframe): Sectional dataframe.
        config (dict): Configuration file.
        prefix (string): prefix to be appended with column names.
        section (strin): Measurements friom which area
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    
    """    
    section_header("Preprocess Data")
    df = df.drop("key_assetid","key_date","key_incident_start_date", "key_incident_end_date", "key_ticket_id")# to match
    df = rename_cols(df, prefix)
    df = change_data_type(df, cols_to_convert=cols_to_convert, datatype=DoubleType())
    df = df.na.drop(subset=[prefix+'assetid',prefix+'datum'])
    df = df.select(*cols)
    return df

def change_data_type(df, cols_to_convert, datatype):
    """
    Change data type for columns from one type to another.
    
    Args:
        df (dataframe): Input spark dataframe. 
        cols_to_convert (list): list of columns.
        datatype(object): Intended data type.
    
    Returns:
        df (dataframe): Spark df with proper datatype.
    
    """
    section_header("Change Data Type")
    for col_name in cols_to_convert:
        df = df.withColumn(col_name, F.col(col_name).cast(datatype))
    return df

def acs_feature_engineering(df,config):
    """
    This Funtion is used to create aggregated features
    
    Args:
        df (dataframe): input dataframe
        config (dict): Configuration file.
        section (string): Functionality area.
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    
    """
    section_header("ACS Feature Engineering")
    aggregations = [F.avg(c).alias(c+"_avg") for c in config["data_gathering"]["features"]["acs"]["measurements"]]
    aggregations = [F.max(c).alias(c+"_max") for c in config["data_gathering"]["features"]["acs"]["measurements"]]+aggregations
    aggregations = [F.min(c).alias(c+"_min") for c in config["data_gathering"]["features"]["acs"]["measurements"]]+aggregations 
    aggregations = [F.sum(c).alias(c+"_sum") for c in config["data_gathering"]["features"]["acs"]["delta"]]+aggregations
    aggregations = [F.max(c).alias(c) for c in config["data_gathering"]["features"]["acs"]["incremental"]]+aggregations
    aggregations = [F.max(c+"_restart").alias(c+"_restart") for c in config["data_gathering"]["features"]["acs"]["incremental"]]+aggregations
    aggregations = [F.count("acs_assetid").alias("acs_transmissions_acs_count")]+aggregations


    df_acs_day = df.groupBy(config["data_gathering"]["features"]["acs"]["grouping_features"]).agg(*aggregations)
    
    transmit_blocks= ["acs_xdslline_transmitBlocksDelta_sum", "acs_xdslline_receiveBlocksDelta_sum"]
    errors_trafic = ['acs_xdslline_atuccrcdelta_sum', 'acs_xdslline_atucfecdelta_sum', 'acs_xdslline_atuchecdelta_sum', 'acs_xdslline_crcdelta_sum', 'acs_xdslline_fecdelta_sum', 'acs_xdslline_hecdelta_sum']
    
    memory_used = ["acs_xdslline_usedMemoryKb_min", "acs_xdslline_usedMemoryKb_avg", "acs_xdslline_usedMemoryKb_max"]
    memory_total = ["acs_xdslline_totalMemoryKb_avg"]
    
    
    df1 =  ratio_generator(df_acs_day, transmit_blocks, errors_trafic)
    df1 =  ratio_generator(df1, memory_total, memory_used)
    
    return df1

def ratio_generator(df, denominators, numerators):
    section_header("Ratio Generator")
    for den in denominators:
        for feature in numerators:
            df = df.withColumn(feature+'_'+den+'_ratio', \
                               F.when((F.col(feature)/F.col(den)).isNotNull(), \
                                      F.col(feature)/F.col(den)).otherwise(0))       
    return df

def gather_data(spark,df_inventory, df_dslam, df_snmp, df_acs, config):
    """This Funtion gather the relevant information of specific measurements.
    
    Args:
        df (dataframe): Sectional dataframe.
        config (dict): Configuration file.
        prefix (string): prefix to be appended with column names.
        section (strin): Measurements friom which area
        
    Returns:
        dataframe :  spark dataframe with loaded data.
    
    """   
    section_header("Gather Data")
    # Gather DSLAM data
    dslam_cols_to_convert = config["data_gathering"]["features"]["dslam"]["measurements"]
    dslam_cols = config["data_gathering"]["features"]["dslam"]["grouping_features"]+config["data_gathering"]["features"]["dslam"]["measurements"]+config["data_gathering"]["features"]["dslam"]["categoricals"]
    df_dslam = preprocess_data(df_dslam,'dslam_',dslam_cols_to_convert,dslam_cols)
    
    # Gather SNMP data
    snmp_cols_to_convert = config["data_gathering"]["features"]["snmp"]["measurements"]
    snmp_cols = config["data_gathering"]["features"]["snmp"]["grouping_features"]+config["data_gathering"]["features"]["snmp"]["measurements"]
    df_snmp = preprocess_data(df_snmp,'snmp_',snmp_cols_to_convert,snmp_cols)   
    
    # Gather ACS data
    acs_cols_to_convert = config["data_gathering"]["features"]["acs"]["delta"]+config["data_gathering"]["features"]["acs"]["incremental"]+config["data_gathering"]["features"]["acs"]["measurements"]
    acs_cols = config["data_gathering"]["features"]["acs"]["grouping_features"]+config["data_gathering"]["features"]["acs"]["measurements"]+ config["data_gathering"]["features"]["acs"]["delta"]+config["data_gathering"]["features"]["acs"]["incremental"]
    
    # Adding incremental features before drop keys + Feature engineering
    df_acs, reset_cols = acs_create_incremental_features(df_acs,config,'acs')
    df_acs = preprocess_data(df_acs,'acs_',acs_cols_to_convert, acs_cols+reset_cols)
    df_acs = acs_feature_engineering(df_acs,config)

    #dropping missing keys
    df_dslam =df_dslam.na.drop(subset=['dslam_assetid','dslam_datum'])
    df_snmp =df_snmp.na.drop(subset=['snmp_assetid','snmp_datum'])
    df_acs = df_acs.na.drop(subset=['acs_assetid','acs_datum'])

    # Drop multiple samples per day
    df_dslam = df_dslam.dropDuplicates(['dslam_assetid','dslam_datum'])
    df_snmp = df_snmp.dropDuplicates(['snmp_assetid','snmp_datum'])
    df_acs = df_acs.dropDuplicates(['acs_assetid','acs_datum'])
    
    # create key
    df_key = create_dates(df_inventory, spark, config)
    print("ABCCD_Identifier")
    print(df_key.columns)

    #Join
    df = df_key.join(df_dslam, [(df_key.assetid == df_dslam.dslam_assetid) & (df_key.date == df_dslam.dslam_datum)], how='left')
    df = df.join(df_snmp, [(df.assetid == df_snmp.snmp_assetid) & (df.date == df_snmp.snmp_datum)], how='left')
    df = df.join(df_acs, [(df.assetid == df_acs.acs_assetid) & (df.date == df_acs.acs_datum)], how='left')
    print("EFGH_Identifier")
    print(df.columns)
    # We drop duplicate column and perform the renaming of columns
    df = df.drop('dslam_assetid','dslam_datum' 'acs_assetid','acs_datum','snmp_assetid', 'snmp_datum')
    df = df.withColumnRenamed('date','datum')
    df = df.withColumnRenamed('acs_crm_serialnumber', 'cpe_serial_number')
    
    #removing Less Data
    #df = remove_less_data(config, df)
    
    #Sorting by date
    df = df.orderBy(['assetid', 'datum'], asc = True)
    
    # create time related features
    df = time_related_features(df)
    
    # Add time index for aggregation
    df = add_time_index(df)
    return df

def time_related_features(df):
    '''
    This is a function to create time related features
    
    Args:
        df (dataframe): Input dataframe
        
    Returns:
        df (dataframe): Input dataframe
        
    '''
    section_header("Time Related Features")
    df = df.withColumn('day_of_month',F.dayofmonth(df.datum))
    df = df.withColumn('day_of_week',F.dayofweek(df.datum))
    df = df.withColumn("datum",F.to_timestamp(F.col("datum"))).withColumn("week_of_month", F.date_format(F.col("datum"), "W"))
    
    return df

def add_time_index(data):
    
    """
    Function to add timeindex for each assetid .
    
    Arg:
        spark (SparkSession): Optional
        data: Dataframe consisting of all the data and respective assetid extracted
    
    Returns:
        data: Time Index of all the dates starting from 0 to 32
    
    """
    section_header("Add Time Index")
    data = data.withColumn('incident_date_string', F.col('incident_start_date').cast(StringType()))
    w = Window.partitionBy(*['assetid','incident_start_date', 'incident_end_date', 'ticket_id']).orderBy(F.desc('datum'))
    data = data.withColumn('time_index',F.row_number().over(w))
    data.drop('incident_date_string')
    return data

