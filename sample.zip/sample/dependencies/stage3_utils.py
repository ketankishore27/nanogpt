#Spark Packages
import pyspark.sql.functions as F
from pyspark.sql import Window
from pyspark.sql import types 
from dependencies.utils import *



def create_aggregation_list(config, mode):
    """Create an aggregated list of features
    
    Args:
        mode (string): Aggregation to be done on mentioned days
        
    Returns:
        list (object): list of features with aggregation of different days
    """
    section_header("Create Aggregation List")
    aggregation_list = []
    for param in config['data_preprocessing']['feature_operation']['numerical']:
        aggregation_list.append(F.avg(param).alias("{}_avg_{}".format(mode, param)))
        aggregation_list.append(F.max(param).alias("{}_max_{}".format(mode, param)))
        aggregation_list.append(F.min(param).alias("{}_min_{}".format(mode, param)))
        aggregation_list.append(F.sum(param).alias("{}_sum_{}".format(mode, param)))
        aggregation_list.append(F.stddev(param).alias("{}_sd_{}".format(mode, param)))
        aggregation_list.append(F.kurtosis(param).alias("{}_krt_{}".format(mode, param)))
        aggregation_list.append(F.skewness(param).alias("{}_skw_{}".format(mode, param)))
        aggregation_list.append((F.max(param)-F.min(param)).alias("{}_max_min_diff_{}".format(mode, param)))

    return aggregation_list

def aggregation_per_window(config, df, mode):
    """Loading data & creating a column
    
    Args:
        df (dataframe): Input dataframe.
        window (string): Different window size
        
    Returns:
        df (dataframe): Aggregated datframe
    """    
    section_header("Aggregation Per Window")
    aggregation_list = create_aggregation_list(config, mode)
    df_window = df.groupby(['assetid','incident_start_date', 'incident_end_date', 'ticket_id']).agg(*aggregation_list)
    return df_window

def rename_cols_subset(df, prefix, cols):
    """Column rename by adding a prefix.
    
    Args:
        df (dataframe): Input dataframe.
        
    Returns:
        df (dataframe): Output datframe with appended prefix to columns.
    """
    section_header("Rename Cols Subset")
    for feature in cols:
        df = df.withColumnRenamed(feature,prefix+feature)
    return df

def get_window_features(df, config, mode):
    
    '''
    Loading data & creating a column
    
    Args:
        df (dataframe): Input dataframe.
        df_key (dataframe): Dataframe with keys
        window (string): Different window size
        
    Returns:
        df_window_agg (dataframe): Aggregated datframe
    '''
    section_header("Get Window Feature")
    for window in [config['data_preprocessing']['window_{}'.format(mode)]]:
        print('for window {}:'.format(mode), window)
        df_window = aggregation_per_window(config, df, mode)
    return df_window


def get_categorical_features (df, config):
    '''
    This function is for combining different features
    
    Args:
        df (dataframe) : Base dataframe
        
    Returns:
        df_categorical (dataframe) : Dataframe with categorical features
    
    '''
    section_header("Get Categorical Feature")
    cols = ['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id'] + config['data_preprocessing']['feature_operation']['categorical']
    df_categorical = df.select(*cols)
    #df_categorical = df_categorical.dropna()
    df_categorical = df_categorical.dropDuplicates(subset=['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id'])
    return df_categorical

def rename_cols(df, prefix):
    """Column renameb by adding a prefix.
    
    Args:
        df (dataframe): Input dataframe.
        
    Returns:
        df (dataframe): Output datframe witha ppended prefix to columns.
    """
    section_header("Rename Cols")
    for feature in df.columns:
        if not feature in ['assetid', 'incident_start_date', 'incident_end_date', 'ticket_id']:
            df = df.withColumnRenamed(feature,prefix+feature)
    return df

def add_trend_features(df, config):
    '''
    This function is for creating trend features for Numerical variables
    
    Args:
        df (dataframe): Input dataframe
        
    Returns:
        df_window_agg (dataframe): Aggregated dataframe with trend features
    
    '''
    section_header("Add Trend Features")
    for feature in config['data_preprocessing']['feature_operation']['numerical']:
        df = df.withColumn(feature+'_avg_trend', F.col("after_avg_{}".format(feature))-F.col("before_avg_{}".format(feature)))
        df = df.withColumn(feature+'_min_trend', F.col("after_min_{}".format(feature))-F.col("before_min_{}".format(feature)))
        df = df.withColumn(feature+'_max_trend', F.col("after_max_{}".format(feature))-F.col("before_max_{}".format(feature)))
        
    return df
