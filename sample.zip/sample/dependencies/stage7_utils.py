# Data Science Packages
import sys

import warnings
import time

#Pyspark packages
from datetime import timedelta
import datetime as dt
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import pandas as pd
import re
from dependencies.stage1_utils import *
from dependencies.stage2_utils import *
from dependencies.batch_id_update_utils import *

#Generic utils for printing and style
from dependencies.utils import *

def fetch_data_s7(spark,config):
    '''
    This function is for filtering cpe type

    Args:
        spark (object) : Spark Session
        log (object): Logger.
        config : config dictionary
    
    Returns:
        df_filtered (dataframe) : Output dataframe
    '''   
    start_time, end_time = time_duration(config['timedeltas']['gap_incident_date'], \
                             config['data_gathering']['seq_len'])
 

    # Load Pol day data
    df_pol_day = spark.sql("select * from {0}.{1} where datum between '{2}' and '{3}' " \
                    .format(config['db']['raw_db_pol_day'], 
                            config['db']['raw_pol_day_table'],
                            start_time, 
                            end_time))

    # Load Xdsl data
    df_xsdl = spark.sql("select * from {0}.{1} where datum between '{2}' and '{3}' " \
                    .format(config['db']['raw_db_xsdl'], 
                            config['db']['raw_xsdl_table'],
                            start_time, 
                            end_time))
        

    return df_pol_day, df_xsdl

def raw_counts_df(args,spark,config):

    #Fetching data from the tables
    df_pol_day, df_xdsl = fetch_data_s7(spark,config)
    df_pol_day, df_xdsl = clean_data(df_pol_day, df_xdsl)
    
    df_pol_day = df_pol_day.select('assetid','datum').distinct()
    df_xdsl = df_xdsl.select('crm_assetId','datum','crm_productClass','eventid').distinct()
    df_xdsl = df_xdsl.withColumnRenamed('crm_assetId','assetid')
    df_xdsl = df_xdsl.withColumnRenamed('crm_productClass','cpe_type')
    
    #Add event date
    event_date = (dt.datetime.now() - timedelta(days=config['timedeltas']['gap_incident_date']))
    event_date = event_date.strftime("%Y-%m-%d")
    
    #Aggregation of transactions for 5 days
    df_xdsl_trans_agg = df_xdsl.groupby('datum','cpe_type').agg(F.countDistinct('eventid').alias('transaction_count'))
    df_xdsl_trans_agg_1 = df_xdsl_trans_agg.filter(F.col('datum')!=event_date)
    df_xdsl_trans_agg_5days = df_xdsl_trans_agg_1.groupby('cpe_type').agg(F.avg('transaction_count').alias('avg_count_no_of_transactions_last_5days_xdsl'))
    
    #Transaction count per day xdsl
    df_xdsl_trans_agg_day = df_xdsl_trans_agg.filter(F.col('datum')==event_date).select('cpe_type','transaction_count')
    df_xdsl_trans_agg_day = df_xdsl_trans_agg_day.withColumnRenamed('transaction_count','count_no_of_transactions_per_day_xdsl')
    
    #Count of assets
    df_pol_day = df_pol_day.join(df_xdsl.select('assetid','datum','cpe_type').distinct(),on=['assetid','datum'],how='left')
    
    df_xdsl_daylevel = df_xdsl.select('assetid','datum','cpe_type').distinct().groupby('datum','cpe_type').agg(F.countDistinct('assetid').alias('count_distinct_assetid_per_day_xdsl')).sort('datum')
    df_poll_daylevel = df_pol_day.groupby('datum','cpe_type').agg(F.countDistinct('assetid').alias('count_distinct_assetid_per_day_pol_day')).sort('datum')
    
    df_xdsl_daylevel_1day = df_xdsl_daylevel.filter(F.col('datum')==event_date).select('cpe_type','count_distinct_assetid_per_day_xdsl')
    df_poll_daylevel_1day = df_poll_daylevel.filter(F.col('datum')==event_date).select('cpe_type','count_distinct_assetid_per_day_pol_day')
    
    #Aggregation of count of assets for 5 days
    df_pol_xdsl = df_xdsl_daylevel.join(df_poll_daylevel,on=['datum','cpe_type'])
    df_pol_xdsl = df_pol_xdsl.filter(F.col('datum')!=event_date)
    df_pol_xdsl_g = df_pol_xdsl.groupby('cpe_type').agg(F.avg('count_distinct_assetid_per_day_xdsl').alias('avg_count_distinct_assetid_last_5days_xdsl'),\
                                                   F.avg('count_distinct_assetid_per_day_pol_day').alias('avg_count_distinct_assetid_last_5days_pol_day'))
    
    # Combine all tables
    df_comb = df_xdsl_daylevel_1day.join(df_poll_daylevel_1day,on=['cpe_type']).join(df_xdsl_trans_agg_day,on=['cpe_type']).join(df_pol_xdsl_g,on=['cpe_type']).join(df_xdsl_trans_agg_5days,on=['cpe_type'])
    df_comb = df_comb.drop("event_date")
    df_comb = df_comb.dropDuplicates()

    # Add dag_run_ids
    df_comb = add_batch_id(df_comb, get_batch_id(args))
    df_comb = df_comb.withColumnRenamed('batchid','dag_run_id')
    df_comb = df_comb.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df_comb = add_time(df_comb, get_time(args))
    df_comb = df_comb.withColumn("event_date", df_comb['timestamp'].cast('date'))
    df_comb = df_comb.select('dag_run_id','cpe_type','count_distinct_assetid_per_day_xdsl','count_distinct_assetid_per_day_pol_day','count_no_of_transactions_per_day_xdsl','avg_count_distinct_assetid_last_5days_xdsl','avg_count_distinct_assetid_last_5days_pol_day','avg_count_no_of_transactions_last_5days_xdsl','event_date')
    
    return df_comb  


def format_gpe_df(config,spark, args):
    """
    Creates a df of count of unique CPE ids from a rolling 14 days within the given timeframe
    
    Args:
        table_name (str) : table name
        start_date (str) : in '2021-07-01' format
        end_date (str) : in '2021-07-01' format
        spark (object) : Spark session.
        cpe_type (str) : CPE Type.
        args (str) : Arguments
    Returns:
        df(dataframe) : Output datarame
    
    """

    df = raw_counts_df(spark,config)
    df = add_batch_id(df, get_batch_id(args))
    df = df.withColumnRenamed('batchid','dag_run_id')
    df = df.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df = add_time(df, get_time(args))
    df = df.withColumn("event_date", df['timestamp'].cast('date'))
    df = df.select('dag_run_id','event_date','cpe_type','count_distinct_assetid_per_day_xdsl','count_distinct_assetid_per_day_pol_day','count_no_of_transactions_per_day_xdsl','avg_count_distinct_assetid_last_5days_xdsl','avg_count_distinct_assetid_last_5days_pol_day','avg_count_no_of_transactions_last_5days_xdsl')

    return df


def funnel(df_inventory, df_stage3, df_dslam, df_snmp, df_acs, spark, config, args, cpe_type):
    '''
    This function is to create the flow of the pipeline 
    
    Args:
        df_inventory (dataframe): Inventory dataframe.
        df_dslam (dataframe): Inventory match with the DSLAM data.
        df_snmp (dataframe): Inventory match with the SNMP data.
        df_acs (dataframe): Inventory match with the ACS data.
        df_stage3 (dataframe): Stage 3 output dataframe.
        start_time (string) : Start date.
        end_time (string) : End date.
        spark (object) : Spark session.
        config (dict) : Configuration dictionary.
        cpe_type (str) : CPE Type.

    Returns:
        df_logging (dataframe) : Output dataframe
    '''
    # Load data
    section_header("BOOSTING PHASE")
    
    #Load Inventory
    df_inventory_unique_ids = df_inventory.select('assetid').distinct().count()
    df_key = create_windowing_per_assetid(spark,df_inventory,config)
    df_key = rename_cols(df_key, 'key_')
    key_count = df_key.count()

    subsection_stats_boosting (df_key, key_count, "Keys Counts")
    subsection_stats_boosting (df_dslam, key_count, "keys Match with DSLAM Counts:")
    subsection_stats_boosting (df_snmp, key_count, "keys Match with SNMP Counts:")
    subsection_stats_boosting (df_acs, key_count, "keys Match with ACS Counts:")
    
    # Gather DSLAM data
    dslam_cols_to_convert = config["data_gathering"]["features"]["dslam"]["measurements"]
    dslam_cols = config["data_gathering"]["features"]["dslam"]["grouping_features"]+config["data_gathering"]["features"]["dslam"]["measurements"]+config["data_gathering"]["features"]["dslam"]["categoricals"]
    df_dslam = preprocess_data(df_dslam,'dslam_',dslam_cols_to_convert,dslam_cols)
    
    # Gather SNMP data
    snmp_cols_to_convert = config["data_gathering"]["features"]["snmp"]["measurements"]
    snmp_cols = config["data_gathering"]["features"]["snmp"]["grouping_features"]+config["data_gathering"]["features"]["snmp"]["measurements"]
    df_snmp = preprocess_data(df_snmp,'snmp_',snmp_cols_to_convert,snmp_cols)   
    
    # Gather ACS data
    acs_cols_to_convert = config["data_gathering"]["features"]["acs"]["delta"]+config["data_gathering"]["features"]["acs"]["incremental"]+config["data_gathering"]["features"]["acs"]["measurements"]
    acs_cols = config["data_gathering"]["features"]["acs"]["grouping_features"]+config["data_gathering"]["features"]["acs"]["measurements"]+ config["data_gathering"]["features"]["acs"]["delta"]+config["data_gathering"]["features"]["acs"]["incremental"]
    df_prev_repeateded_cpes = get_prev_repeateded_cpes(df_acs)
    df_acs = preprocess_data(df_acs,'acs_',acs_cols_to_convert, acs_cols)
    
    # Dropping missing keys
    df_dslam =df_dslam.na.drop(subset=['dslam_assetid','dslam_datum'])  
    df_snmp =df_snmp.na.drop(subset=['snmp_assetid','snmp_datum'])
    df_acs = df_acs.na.drop(subset=['acs_assetid','acs_datum'])

    # Drop multiple samples per day
    df_dslam = df_dslam.dropDuplicates(['dslam_assetid','dslam_datum'])
    df_snmp = df_snmp.dropDuplicates(['snmp_assetid','snmp_datum'])
    df_acs = df_acs.dropDuplicates(['acs_assetid','acs_datum'])
    
    dslam_cnt =  df_dslam.count()
    dslam_unique_ids = df_dslam.select('dslam_assetid').distinct().count()
    snmp_cnt = df_snmp.count()
    snmp_unique_ids = df_snmp.select('snmp_assetid').distinct().count()
    acs_cnt =  df_acs.count()
    acs_unique_ids = df_acs.select('acs_assetid').distinct().count()

    # Join
    df_key = df_key = create_windowing_per_assetid(spark,df_inventory,config)
    df = df_key.join(df_dslam, [(df_key.assetid == df_dslam.dslam_assetid) & (df_key.date == df_dslam.dslam_datum)], how='left')
    df = df.join(df_snmp, [(df.assetid == df_snmp.snmp_assetid) & (df.date == df_snmp.snmp_datum)], how='left')
    df = df.join(df_acs, [(df.assetid == df_acs.acs_assetid) & (df.date == df_acs.acs_datum)], how='left')

    # We drop duplicate column and perform the renaming of columns
    df = df.drop('dslam_assetid','dslam_datum' 'acs_assetid','acs_datum','snmp_assetid', 'snmp_datum', 'lb_networkdeviceid', 'ub_networkdeviceid')
    df = df.withColumnRenamed('date','datum')
    df = df.withColumnRenamed('acs_crm_serialnumber', 'cpe_serial_number')
    all_join_ids = df.select('assetid').distinct().count()
    cnt = df.count()
    
    # Removing Less Data
    df = remove_less_data(config, df)
    rmv_cnt_unique_ids = df.select('assetid').distinct().count()
    rmv_cnt = df.count()
    
    # Sorting by date
    df = remove_previously_repeateded_cpe(df, df_prev_repeateded_cpes)
    df = df.orderBy(['assetid', 'datum'], asc = True)
    rmv_prv_rbt_cnt_unique_ids = df.select('assetid').distinct().count()
    rmv_prv_rbt_cnt = df.count()

    # Show Stats
    subsection_stats_summary(dslam_cnt, snmp_cnt, acs_cnt, key_count, cnt, rmv_cnt, rmv_prv_rbt_cnt)

    # Log Stage 3
    stage3_unique_ids = df_stage3.select('assetid').distinct().count()
    stage3_samples = df_stage3.count()

    # Log count for Pipeline flow
    df_logging_stage2 = create_df_logging_stage2(args,cpe_type, df_inventory_unique_ids,key_count,dslam_unique_ids,dslam_cnt, snmp_unique_ids,snmp_cnt, acs_unique_ids, acs_cnt, all_join_ids, cnt, rmv_cnt_unique_ids, rmv_cnt, rmv_prv_rbt_cnt_unique_ids, rmv_prv_rbt_cnt, spark)
    df_logging_stage3 = create_df_for_logging_stage3(args,cpe_type,stage3_unique_ids, stage3_samples,spark)
    df_logging = df_logging_stage2.join(df_logging_stage3,on=["dag_run_id","event_date","cpe_type"],how='inner')
    total_cols = ["dag_run_id","event_date","cpe_type","stage1_unique_ids","stage1_unique_samples","stage2_dslam_unique_ids","stage2_dslam_samples", "stage2_snmp_unique_ids", "stage2_snmp_samples", "stage2_acs_unique_ids", "stage2_acs_samples", "stage2_unique_ids", "stage2_samples", "stage2_min_reqd_unique_ids" ,"stage2_min_reqd_samples", "stage2_prev_repeateded_cpes","stage2_prev_repeateded_samples","stage3_unique_ids", "stage3_samples"]
    df_logging = df_logging.select(*total_cols).distinct()

    return df_logging



def data_drift(df,config,args,cpe_type):
    '''
    This function is to monitor the data drift in the raw parameters
    
    Args:
        df_stage2 (dataframe): Stage 2 output dataframe.
        config (dict) : Configuration dictionary.
        cpe_type (str) : CPE Type.

    Returns:
        df_stage2_param (dataframe) : Output dataframe
    '''

    # Log Parameters for Data Drift

    # Create format
    df = add_batch_id(df, get_batch_id(args))
    df = df.withColumnRenamed('batchid','dag_run_id')
    df = df.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df = df.withColumn('cpe_type',F.lit(cpe_type))
    df = df.withColumnRenamed('incident_date','event_date')

    # Get event count of a time-series
    df_day_cnt = df.groupby('dag_run_id','event_date','cpe_type','assetid').agg(F.count('assetid').alias('day_cnt'))
    df_day_cnt = df_day_cnt.groupby('dag_run_id','event_date','cpe_type').agg(F.avg('day_cnt').alias('avg_day_cnt'))

    # Stats of Numerical variables
    num_cols = config['data_preprocessing']['feature_operation']['numerical']
    func = [F.avg, F.count]
    expr = [f(F.col(coln)).alias(str(f.__name__)+'_'+str(F.col(coln))) for f in func for coln in num_cols]
    groupby_cols = ['dag_run_id','event_date','cpe_type']
    df_agg = df.groupby(*groupby_cols).agg(*expr)

    # Rename columns in desired format
    df_agg = df_agg.select([F.col(col).alias(re.sub('[><]',"",col)) for col in df_agg.columns])
    df_agg = df_agg.select([F.col(col).alias(re.sub("Column","",col)) for col in df_agg.columns])
    df_agg = df_agg.join(df_day_cnt,on=['dag_run_id','event_date','cpe_type'],how='inner')
    total_cols = df_agg.columns
    df_agg = df_agg.select(*total_cols).distinct()
    df_agg = df_agg.dropDuplicates()

    return df_agg


def recommendation_stats(df):
    '''
    This function is to monitor the data drift in the raw parameters
    
    Args:
        df_stage6 (dataframe): Stage 6 output dataframe.
        cpe_type (str) : CPE Type.

    Returns:
        df_stage6_avg (dataframe) : Output dataframe
    '''
    # Load data
    section_header("RECOMMENDATION PHASE")

    df_agg = df.groupby('dag_run_id','event_date','cpe_type','testing_group').agg( F.count('probability_1').alias('total_rec_cnt'),\
                                                                           F.min('probability_1').alias('min_prob'),\
                                                                           F.expr('percentile(probability_1, array(0.25))')[0].alias('perc_25_prob'),\
                                                                           F.avg('probability_1').alias('avg_prob'),
                                                                           F.expr('percentile(probability_1, array(0.75))')[0].alias('perc_75_prob'),\
                                                                           F.expr('percentile(probability_1, array(0.90))')[0].alias('perc_90_prob'),    
                                                                           F.max('probability_1').alias('max_prob'),\
                                                                           F.stddev('probability_1').alias('std_prob')
                                                                          )
    total_cols = df_agg.columns
    df_agg = df_agg.select(*total_cols).distinct()
    df_agg = df_agg.dropDuplicates()
    df_agg = df_agg.orderBy('event_date','cpe_type','testing_group')
    
    return df_agg
