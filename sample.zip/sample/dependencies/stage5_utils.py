# Data Science Packages
import sys
import os
from pyspark.sql import functions as F
from pyspark.sql.functions import udf
from pyspark.sql.types import FloatType
from dependencies.utils import *

os.environ['PYSPARK_PYTHON'] = sys.executable
os.environ['PYSPARK_DRIVER_PYTHON'] = sys.executable


def get_pred(df, model, model_id=1):
    '''
    This function get the prediction given a model. Additionally it add a sufix the
    the obtaing fields: 'prediction','probability','rawPrediction' basedon the modelid.
    Also it extract the probabilities for unhealty predictions.
    
    Args:
        df (dataframe): Input data frame with base features.
        model (object): fitted model.
        modelid (int): Model idx.
    '''
    # Data Transformation
    df_pred = model.transform(df)
    
    # Select predictions & Probabilities and rename
    features = ['prediction','probability','rawPrediction']
        
    for feature in features:
        df_pred = df_pred.withColumnRenamed(feature, feature+'_'+str(model_id))
    
    # Dropping the vector feature for inference with other models
    df_pred = df_pred.drop('features')
    
    # Extract Unhealty Probability
    prob_unhealty=udf(lambda v:float(v[1]),FloatType())
    df_pred = df_pred.withColumn('probability_unhealty_'+str(model_id), prob_unhealty('probability_'+str(model_id)))

    return df_pred