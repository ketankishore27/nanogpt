# -*- coding: utf-8 -*-
"""
batch_id_update_utils.py

This module contains reusable function for multiple components.

.. _Google Python Style Guide:
   http://google.github.io/styleguide/pyguide.html

"""
__copyright__ = "Deutsche Telekom"

from pyspark.sql import types
from pyspark.sql import functions as F


def get_batch_id(args):
    """Get Batch Id from arguments.
    
    Args:
        args (list): List of arguments.

    Returns:
        str: Batch Id.
    """
    try:
        batch_id = args[1]
    except: # pylint: disable=W0702
        batch_id = 'none-batchid'
 
    return str(batch_id)

def get_time(args):
    """Get Batch Id from arguments.
    
    Args:
        args (list): List of arguments.

    Returns:
        str: Timestamp.
    """  
    print('args',args)
    if len(args) == 5:
     timestamp = args[3]+ " " + args[4]
    else:
     timestamp = None
    return timestamp

def add_batch_id(df, batch_id):
    """Adds batch id as a new colum to a dataframe.

    Args:
        df (dataframe): Input dataframe.
        batch_id (int): Batch identifier.

    Returns:
        dataframe: Output dataframe with added batch-id.
    """
    df = df.withColumn('batchid', F.lit(batch_id))
    return df

def add_time(df, timestamp):
    """Adds batch id as a new colum to a dataframe.

    Args:
        df (dataframe): Input dataframe.
        batch_id (int): Batch identifier.

    Returns:
        dataframe: Output dataframe with added batch-id.
    """
    if  timestamp is not None:
        df = df.withColumn("timestamp", F.lit(str(timestamp)).cast(types.TimestampType()))
    else:
        df = df.withColumn("timestamp", F.lit("2000-01-1 00:00:00").cast(types.TimestampType()))
    return df
