"""
spark.py
Module containing helper function for use with Apache Spark
"""
from os import environ
from pyspark.sql import SparkSession
import __main__
from dependencies import logging
from dependencies.config import cfg


def start_spark(app_name='my_spark_app', master='local[*]'): # pylint: disable=W0102, R0914
    """Start Spark session, get Spark logger and load config files.
    Start a Spark session on the worker node and register the Spark
    application with the cluster. Note, that only the app_name argument
    will apply when this is called from a script sent to spark-submit.
    All other arguments exist solely for testing the script from within
    an interactive Python console.

    Args:
        app_name (str): Name of Spark app.
        master: (str) Cluster connection details (defaults to local[*]).
    Returns:
        tuple: A tuple of references to the Spark session, logger and
            config dict (only if available).
    """
    spark_builder = (
        SparkSession
        .builder
        .master(master)
        .config("spark.driver.memory", "14g") \
        .appName(app_name))

    # create session and retrieve Spark logger object
    spark_sess = spark_builder.getOrCreate()
    spark_sess.sparkContext.setLogLevel('WARN')
    
    return spark_sess, cfg
