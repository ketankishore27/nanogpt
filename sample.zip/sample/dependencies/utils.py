from pyspark.sql import functions as F
from dependencies.batch_id_update_utils import *
from datetime import timedelta
import datetime as dt

def stage_header(config, 
                 info= None):
    '''
    This funtion help to print sections.
    
    Args:
        stage_number (int): Section name
        config (dict): Cofiguration file.
        info (str): Description stage.
    '''
    dict_roman = {
        1: "I.",
        2: "II.",
        3: "III.",
        4: "IV.",
        5: "V.",
        6: "VI.",
        7: "VII."  
    }
    print('\n')
    print("="*70)
    print("++++++++++++++++++++++++++++++++++++++++++++++++++++")
    print("++++++++++++++++++++++++++++++++++++++++o++++++++++++")
    print("="*70)
    print('\n')
    #print("CPE type: " +config["cpe_type"])
    if info:
        print("Description Stage:" )
        info = str(info)
        words = list(info.split(' '))
        len_sentence = 0
        sentence = []
        while  len(words)>0:
            w = words.pop(0)
            sentence.append(w)
            sentence.append(' ')
            len_sentence += len(list(w)) + 1
            if len_sentence>60:
                print(''.join(sentence))
                sentence = []
                len_sentence = 0
        print(''.join(sentence))
    print('\n')
    

def section_header(title):
    '''
    This funtion help to print sections.
    
    Args:
        title (str): Section name
    '''
    print('\n')
    print("="*70)
    print(str(title))
    print("="*70)
    print('\n')
    

def subsection_header(title):
    '''
    This funtion help to print subsection.
    
    Args:
        title (str): Subsection name
    '''
    print('\n')
    print("-"*70)
    print(str(title))
    print("-"*70)
    
    

def subsection_stats_boosting (df, key_count, tag):
    '''
    This funtion get basic stats in boosting stage.
    
    Args:
        df (dataframe): Target dataframe
        key_count (int): Count unique keys.
        tag (str): Operation name
    '''
    subsection_header(tag)
    count = df.count()
    print('Total records after inner join with Keys:',  count)
    print('Total unique values [assetid, key_incident_date]:',df.select('key_assetid','key_incident_date').distinct().count())
    print('% Drop in Match:', (key_count - count) / float(key_count) * 100)



def subsection_stats_preboosting(df_inventory):
    '''
    This funtion show basict stats of the inventory and time range.
    
    Args:
        df (dataframe): Target dataframe
        key_count (int): Count unique keys.
        tag (str): Operation name
    '''
    
    subsection_header("Inventory Stage Counts:")
    print('Inventory Cpes:', df_inventory.select('assetid').distinct().count())
    print('Inventory Cpes with incident date:', df_inventory.select('assetid','incident_date').distinct().count())
    print('Total count:', df_inventory.count())
    print(df_inventory.groupby('label').count().show(vertical=True))
    
    # subsection_header("Max Time Range Query:")
    # print("Start Date:",start_time)
    # print("End Date:",end_time)
    
    
def subsection_stats_summary (dslam_cnt, snmp_cnt, acs_cnt, key_cnt, cnt, rmv_cnt, rmv_prv_rbt_cnt):
    """
    Function show basic stadistics after data gathering.
    """
    
    print('DSLAM count: ', dslam_cnt)
    print('SNMP count: ', snmp_cnt)
    print('ACS count: ', acs_cnt)
    print('Key count:', key_cnt)
    print('Data Gathering output count:',cnt)
    print('Removing Less data drop:', (cnt - rmv_cnt) / float(cnt+1) * 100)
    print('Removing Previously repeateded cpe data drop:',(rmv_cnt-rmv_prv_rbt_cnt)/float(rmv_cnt+1)*100)


def create_df_logging_stage2(args, cpe_type,df_inventory_cnt,key_count,dslam_unique_ids,dslam_cnt, snmp_unique_ids,snmp_cnt, acs_unique_ids, acs_cnt, all_join_ids,cnt, rmv_cnt_unique_ids, rmv_cnt, rmv_prv_rbt_cnt_unique_ids, rmv_prv_rbt_cnt, spark):
    df_logging_stage2 = spark.createDataFrame([(df_inventory_cnt,key_count, dslam_unique_ids, dslam_cnt, snmp_unique_ids, snmp_cnt, acs_unique_ids, acs_cnt,all_join_ids ,cnt, rmv_cnt_unique_ids,rmv_cnt, rmv_prv_rbt_cnt_unique_ids,rmv_prv_rbt_cnt)],
                                   ["stage1_unique_ids","stage1_unique_samples","stage2_dslam_unique_ids","stage2_dslam_samples", "stage2_snmp_unique_ids", "stage2_snmp_samples", "stage2_acs_unique_ids", "stage2_acs_samples", "stage2_unique_ids", "stage2_samples", "stage2_min_reqd_unique_ids", "stage2_min_reqd_samples", "stage2_prev_repeateded_cpes","stage2_prev_repeateded_samples"])
   
    df_logging_stage2 = df_logging_stage2.select("stage1_unique_ids","stage1_unique_samples","stage2_dslam_unique_ids","stage2_dslam_samples", "stage2_snmp_unique_ids", "stage2_snmp_samples", "stage2_acs_unique_ids", "stage2_acs_samples", "stage2_unique_ids", "stage2_samples", "stage2_min_reqd_unique_ids", "stage2_min_reqd_samples", "stage2_prev_repeateded_cpes","stage2_prev_repeateded_samples")
    # Add format
    df_logging_stage2 = add_batch_id(df_logging_stage2, get_batch_id(args))
    df_logging_stage2 = df_logging_stage2.withColumnRenamed('batchid','dag_run_id')
    df_logging_stage2 = df_logging_stage2.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df_logging_stage2 = add_time(df_logging_stage2, get_time(args))
    df_logging_stage2 = df_logging_stage2.withColumn("event_date", df_logging_stage2['timestamp'].cast('date'))
    df_logging_stage2 = df_logging_stage2.withColumn('cpe_type',F.lit(cpe_type))
   
    return df_logging_stage2

def create_df_for_logging_stage3(args, cpe_type,stage3_unique_ids, stage3_samples,spark):
    df_logging_stage3 = spark.createDataFrame([(stage3_unique_ids, stage3_samples)],
                                   ["stage3_unique_ids", "stage3_samples"])
    df_logging_stage3 = df_logging_stage3.select("stage3_unique_ids", "stage3_samples")
     # Add format
    df_logging_stage3 = add_batch_id(df_logging_stage3, get_batch_id(args))
    df_logging_stage3 = df_logging_stage3.withColumnRenamed('batchid','dag_run_id')
    df_logging_stage3 = df_logging_stage3.withColumn('dag_run_id', F.col('dag_run_id').cast('string'))
    df_logging_stage3 = add_time(df_logging_stage3, get_time(args))
    df_logging_stage3 = df_logging_stage3.withColumn("event_date", df_logging_stage3['timestamp'].cast('date'))
    df_logging_stage3 = df_logging_stage3.withColumn('cpe_type',F.lit(cpe_type))
    return df_logging_stage3

def time_duration(gap_incident_date, seq_len):
    """ Function to define start time and end time for the query
    Args:
        enddate (int): end date for data load in days.
        startdate (int): start date for date load in days.

    Returns:
      {
      object: endtime of query,
      object: starttime of query
      }
    """
    end_time_dt = (dt.datetime.now() - timedelta(days=gap_incident_date))
    end_time = end_time_dt.strftime("%Y-%m-%d")
    start_time = (end_time_dt - timedelta(days=seq_len)).strftime("%Y-%m-%d")
    return start_time, end_time

def load_data(path,spark):
    """ Function to load data
    Args:
        path (str): Path for the data.
        spark (object): Spark session.

    Returns:
        df (dataframe) : Output dataframe
    """

    df = spark.read.parquet(path)
    cols = df.columns
    df = df.select(*cols).distinct()

    return df
